// Este archivo define tipos compartidos entre la base de datos y la UI para evitar problemas de tipado

// Combinando los tipos del módulo de la base de datos y local
export type CommonModule = {
  id: number;
  title: string;
  description: string;
  content: string;
  pdfPath: string;
  videoUrl?: string | null;
  videoTitle?: string | null;
  orderIndex?: number;
  isVideoComplement?: boolean | null;
  createdAt?: Date | string;
  updatedAt?: Date | string;
};
import { useState, useEffect } from "react";
import { Switch, Route, Router } from "wouter";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "@/lib/protected-route";

import PasswordGate from "./pages/PasswordGate";
import Home from "./pages/Home";
import NotFound from "@/pages/not-found";
import AuthPage from "@/pages/auth-page";
import Dashboard from "@/pages/dashboard";
import FarmForm from "@/pages/farm-form";
import UserProfile from "@/pages/user-profile";
import VideosPage from "@/pages/videos-page";

function App() {
  const [isCourseAuthenticated, setIsCourseAuthenticated] = useState<boolean>(false);

  useEffect(() => {
    // Check if the user is already authenticated for course access
    const authStatus = localStorage.getItem("curso-authenticated");
    if (authStatus === "true") {
      setIsCourseAuthenticated(true);
    }
  }, []);

  const handleCourseAuthentication = (status: boolean) => {
    setIsCourseAuthenticated(status);
    if (status) {
      localStorage.setItem("curso-authenticated", "true");
    } else {
      localStorage.removeItem("curso-authenticated");
    }
  };

  // No permitir acceso al curso si no tiene la contraseña
  if (!isCourseAuthenticated) {
    return <PasswordGate onAuthenticate={handleCourseAuthentication} />;
  }

  return (
    <AuthProvider>
      <Router>
        <Switch>
          {/* Rutas públicas */}
          <Route path="/" component={Home} />
          <Route path="/auth" component={AuthPage} />
          <Route path="/videos" component={VideosPage} />
          
          {/* Rutas protegidas que requieren inicio de sesión */}
          <ProtectedRoute path="/dashboard" component={Dashboard} />
          <ProtectedRoute path="/farms/new" component={FarmForm} />
          <ProtectedRoute path="/farms/:id" component={FarmForm} />
          <ProtectedRoute path="/profile" component={UserProfile} />
          
          {/* Ruta 404 */}
          <Route component={NotFound} />
        </Switch>
      </Router>
    </AuthProvider>
  );
}

export default App;

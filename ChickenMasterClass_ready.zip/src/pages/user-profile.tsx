import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, getQueryFn, queryClient } from "@/lib/queryClient";
import { User, Database, Settings, ArrowLeft, Save } from "lucide-react";

import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";

// Esquema de validación para el formulario de perfil
const profileSchema = z.object({
  farmName: z.string().min(2, "El nombre debe tener al menos 2 caracteres").max(50),
  farmLocation: z.string().min(2, "La ubicación debe tener al menos 2 caracteres").max(100),
  farmSize: z.string().optional(),
  henCount: z.string().optional(),
});

type ProfileFormValues = z.infer<typeof profileSchema>;

export default function UserProfile() {
  const [location, navigate] = useLocation();
  const { user, logoutMutation } = useAuth();
  const { toast } = useToast();
  
  // Redirigir si no hay usuario
  useEffect(() => {
    if (!user) {
      navigate("/auth");
    }
  }, [user, navigate]);

  // Definir un tipo para los datos del perfil
  type UserProfile = {
    userId: number;
    username: string;
    email: string;
    farmName: string;
    farmLocation: string;
    farmSize: string;
    henCount: string;
  };

  // Obtener perfil del usuario
  const { data: profile, isLoading: profileLoading } = useQuery<UserProfile>({
    queryKey: ["/api/user/profile"],
    queryFn: getQueryFn({ on401: "throw" }),
  });

  // Formulario con valores por defecto
  const form = useForm<ProfileFormValues>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      farmName: "",
      farmLocation: "",
      farmSize: "",
      henCount: "",
    },
  });
  
  // Actualizar formulario cuando se carguen los datos
  useEffect(() => {
    if (profile) {
      form.reset({
        farmName: profile.farmName || "",
        farmLocation: profile.farmLocation || "",
        farmSize: profile.farmSize || "",
        henCount: profile.henCount || "",
      });
    }
  }, [profile, form]);

  // Mutación para actualizar el perfil
  const updateProfileMutation = useMutation({
    mutationFn: async (data: ProfileFormValues) => {
      const res = await apiRequest("POST", "/api/user/profile", data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user/profile"] });
      toast({
        title: "Perfil actualizado",
        description: "La información de tu granja ha sido actualizada correctamente.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error al actualizar",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Enviar el formulario
  const onSubmit = (data: ProfileFormValues) => {
    updateProfileMutation.mutate(data);
  };

  if (!user) {
    // Renderizado de carga o página vacía mientras redirige
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }

  return (
    <div className="container py-8 max-w-5xl">
      <div className="flex items-center mb-8">
        <Button variant="ghost" onClick={() => navigate("/")} className="mr-4">
          <ArrowLeft className="mr-2 h-4 w-4" /> Volver
        </Button>
        <h1 className="text-3xl font-bold gradient-heading">Mi Perfil</h1>
      </div>

      <Tabs defaultValue="profile" className="w-full">
        <TabsList className="mb-8">
          <TabsTrigger value="profile">Información Personal</TabsTrigger>
          <TabsTrigger value="farm">Datos de mi Granja</TabsTrigger>
        </TabsList>
        
        <TabsContent value="profile">
          <Card>
            <CardHeader>
              <CardTitle>Información de Usuario</CardTitle>
              <CardDescription>
                Aquí puedes ver la información asociada a tu cuenta.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-4 mb-6">
                <div className="bg-primary/10 p-6 rounded-full">
                  <User className="h-12 w-12 text-primary" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold">{user.username}</h3>
                  <p className="text-gray-500">{user.email}</p>
                </div>
              </div>
              
              <Separator />
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                <div>
                  <h4 className="text-sm font-medium text-gray-500 mb-1">Nombre de usuario</h4>
                  <p className="text-lg">{user.username}</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-gray-500 mb-1">Correo electrónico</h4>
                  <p className="text-lg">{user.email}</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-gray-500 mb-1">Fecha de registro</h4>
                  <p className="text-lg">{user.createdAt ? new Date(user.createdAt).toLocaleDateString() : "N/A"}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="farm">
          <Card>
            <CardHeader>
              <CardTitle>Información de mi Granja</CardTitle>
              <CardDescription>
                Completa la información sobre tu granja para personalizar tu experiencia.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="farmName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Nombre de la Granja</FormLabel>
                          <FormControl>
                            <Input placeholder="Mi Granja Avícola" {...field} />
                          </FormControl>
                          <FormDescription>
                            El nombre con el que identificas tu granja.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="farmLocation"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Ubicación</FormLabel>
                          <FormControl>
                            <Input placeholder="Ciudad, Estado" {...field} />
                          </FormControl>
                          <FormDescription>
                            Dónde se encuentra ubicada tu granja.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="farmSize"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Tamaño del terreno (m²)</FormLabel>
                          <FormControl>
                            <Input type="number" placeholder="500" {...field} />
                          </FormControl>
                          <FormDescription>
                            Extensión aproximada de tu granja en metros cuadrados.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="henCount"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Número de gallinas</FormLabel>
                          <FormControl>
                            <Input type="number" placeholder="100" {...field} />
                          </FormControl>
                          <FormDescription>
                            Cantidad total de gallinas en tu granja.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <Button 
                    type="submit" 
                    className="w-full" 
                    disabled={updateProfileMutation.isPending}
                  >
                    {updateProfileMutation.isPending ? (
                      <div className="animate-spin mr-2 h-4 w-4 border-2 border-t-transparent rounded-full" />
                    ) : (
                      <Save className="mr-2 h-4 w-4" />
                    )}
                    Guardar Información
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
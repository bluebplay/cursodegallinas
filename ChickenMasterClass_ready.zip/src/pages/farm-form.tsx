import { useState, useEffect } from "react";
import { useLocation, useParams } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { getQueryFn, apiRequest, queryClient } from "@/lib/queryClient";
import { Farm } from "@shared/schema";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { ArrowLeft, Save, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const farmSchema = z.object({
  name: z.string().min(3, { message: "El nombre debe tener al menos 3 caracteres" }),
  location: z.string().optional(),
  size: z.string().optional(),
  henCapacity: z.coerce.number().int().positive().optional(),
});

type FarmFormValues = z.infer<typeof farmSchema>;

export default function FarmForm() {
  const { id } = useParams<{ id: string }>();
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  const isEditing = id !== "new";

  // Obtener datos de la granja si estamos editando
  const { data: farm, isLoading } = useQuery<Farm>({
    queryKey: [`/api/farms/${id}`],
    queryFn: getQueryFn({ on401: "throw" }),
    enabled: isEditing && !!user,
  });

  const form = useForm<FarmFormValues>({
    resolver: zodResolver(farmSchema),
    defaultValues: {
      name: "",
      location: "",
      size: "",
      henCapacity: undefined,
    },
  });

  // Cargar datos de la granja en el formulario cuando estamos editando
  useEffect(() => {
    if (farm && isEditing) {
      form.reset({
        name: farm.name,
        location: farm.location || "",
        size: farm.size || "",
        henCapacity: farm.henCapacity || undefined,
      });
    }
  }, [farm, isEditing, form]);

  // Mutación para crear una nueva granja
  const createFarmMutation = useMutation({
    mutationFn: async (data: FarmFormValues) => {
      const res = await apiRequest("POST", "/api/farms", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/farms"] });
      toast({
        title: "Granja creada",
        description: "La granja ha sido creada exitosamente",
      });
      navigate("/dashboard");
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "No se pudo crear la granja",
        variant: "destructive",
      });
    },
  });

  // Mutación para actualizar una granja existente
  const updateFarmMutation = useMutation({
    mutationFn: async (data: FarmFormValues) => {
      const res = await apiRequest("PATCH", `/api/farms/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/farms/${id}`] });
      queryClient.invalidateQueries({ queryKey: ["/api/farms"] });
      toast({
        title: "Granja actualizada",
        description: "La granja ha sido actualizada exitosamente",
      });
      navigate("/dashboard");
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "No se pudo actualizar la granja",
        variant: "destructive",
      });
    },
  });

  // Mutación para eliminar una granja
  const deleteFarmMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("DELETE", `/api/farms/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/farms"] });
      toast({
        title: "Granja eliminada",
        description: "La granja ha sido eliminada exitosamente",
      });
      navigate("/dashboard");
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "No se pudo eliminar la granja",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: FarmFormValues) => {
    if (isEditing) {
      updateFarmMutation.mutate(data);
    } else {
      createFarmMutation.mutate(data);
    }
  };

  const handleDelete = () => {
    if (confirm("¿Estás seguro que deseas eliminar esta granja? Esta acción no se puede deshacer.")) {
      deleteFarmMutation.mutate();
    }
  };

  if (isLoading && isEditing) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <p>Cargando datos de la granja...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4">
      <div className="max-w-2xl mx-auto">
        <Button 
          variant="ghost" 
          className="mb-4 flex items-center gap-2" 
          onClick={() => navigate("/dashboard")}
        >
          <ArrowLeft className="h-4 w-4" />
          Volver al dashboard
        </Button>

        <Card>
          <CardHeader>
            <CardTitle>{isEditing ? "Editar Granja" : "Crear Nueva Granja"}</CardTitle>
            <CardDescription>
              {isEditing 
                ? "Actualiza la información de tu granja avícola" 
                : "Completa los datos para registrar una nueva granja"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Nombre de la granja *</FormLabel>
                      <FormControl>
                        <Input placeholder="Mi Granja Avícola" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="location"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Ubicación</FormLabel>
                      <FormControl>
                        <Input placeholder="Dirección o ubicación" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="size"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Tamaño</FormLabel>
                      <FormControl>
                        <Input placeholder="Ej: 500 m²" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="henCapacity"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Capacidad de aves</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          placeholder="Ej: 100" 
                          {...field}
                          value={field.value || ""}
                          onChange={(e) => {
                            const value = e.target.value === "" ? undefined : parseInt(e.target.value);
                            field.onChange(value);
                          }}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="flex justify-between pt-4">
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => navigate("/dashboard")}
                  >
                    Cancelar
                  </Button>
                  <div className="flex gap-2">
                    {isEditing && (
                      <Button 
                        type="button" 
                        variant="destructive"
                        onClick={handleDelete}
                        disabled={deleteFarmMutation.isPending}
                      >
                        <Trash2 className="h-4 w-4 mr-2" />
                        Eliminar
                      </Button>
                    )}
                    <Button 
                      type="submit" 
                      disabled={createFarmMutation.isPending || updateFarmMutation.isPending}
                    >
                      <Save className="h-4 w-4 mr-2" />
                      {isEditing ? "Guardar cambios" : "Crear granja"}
                    </Button>
                  </div>
                </div>
              </form>
            </Form>
          </CardContent>
          <CardFooter className="flex justify-center text-sm text-muted-foreground">
            {isEditing ? "Actualizado" : "Creado"}: {new Date().toLocaleDateString()}
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}
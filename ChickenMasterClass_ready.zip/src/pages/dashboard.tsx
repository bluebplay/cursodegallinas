import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { getQueryFn } from "@/lib/queryClient";
import { Farm } from "@shared/schema";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { PlusCircle, BarChart, Weight, Activity, Egg, ChevronRight } from "lucide-react";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export default function Dashboard() {
  const [location, navigate] = useLocation();
  const { user, logoutMutation } = useAuth();
  const [activeTab, setActiveTab] = useState<string>("farms");

  const { data: farms, isLoading: farmsLoading } = useQuery<Farm[]>({
    queryKey: ["/api/farms"],
    queryFn: getQueryFn({ on401: "throw" }),
    enabled: !!user,
  });

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const handleCreateFarm = () => {
    navigate("/farms/new");
  };

  const handleFarmClick = (farmId: number) => {
    navigate(`/farms/${farmId}`);
  };

  return (
    <div className="flex flex-col min-h-screen">
      {/* Header */}
      <header className="bg-background border-b border-border py-3 px-4 flex justify-between items-center">
        <div className="flex items-center">
          <h1 className="text-xl font-bold text-primary mr-2">Curso de Gallinas Ponedoras</h1>
          <span className="text-sm bg-primary/10 text-primary px-2 py-1 rounded">Dashboard</span>
        </div>
        <div className="flex items-center space-x-4">
          <span className="text-sm text-muted-foreground">
            Hola, {user?.firstName || user?.username}
          </span>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm">Opciones</Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>Mi cuenta</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => navigate("/")}>
                Ver material del curso
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => navigate("/profile")}>
                Mi perfil
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={handleLogout}>
                Cerrar sesión
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </header>

      {/* Main content */}
      <main className="flex-1 p-6 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid grid-cols-5 w-full mb-6">
              <TabsTrigger value="farms">Mis Granjas</TabsTrigger>
              <TabsTrigger value="financials">Proyecciones</TabsTrigger>
              <TabsTrigger value="weights">Registro Peso</TabsTrigger>
              <TabsTrigger value="health">Registro Salud</TabsTrigger>
              <TabsTrigger value="eggs">Producción Huevos</TabsTrigger>
            </TabsList>
            
            <TabsContent value="farms">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {/* Tarjeta para crear nueva granja */}
                <Card className="border-dashed border-2 bg-background/50 hover:bg-background/80 transition-colors cursor-pointer" onClick={handleCreateFarm}>
                  <CardContent className="flex flex-col items-center justify-center p-6 h-full min-h-[200px]">
                    <PlusCircle className="h-12 w-12 text-primary/50 mb-4" />
                    <h3 className="text-lg font-medium">Crear nueva granja</h3>
                    <p className="text-sm text-muted-foreground text-center mt-2">
                      Añade una nueva granja para gestionar tu producción avícola
                    </p>
                  </CardContent>
                </Card>

                {/* Listado de granjas existentes */}
                {farmsLoading ? (
                  <Card>
                    <CardContent className="flex items-center justify-center p-6 h-full min-h-[200px]">
                      <p className="text-muted-foreground">Cargando granjas...</p>
                    </CardContent>
                  </Card>
                ) : farms?.length === 0 ? (
                  <Card>
                    <CardContent className="flex flex-col items-center justify-center p-6 h-full min-h-[200px]">
                      <p className="text-muted-foreground text-center">
                        No tienes granjas registradas. ¡Crea tu primera granja para comenzar!
                      </p>
                    </CardContent>
                  </Card>
                ) : (
                  farms?.map((farm) => (
                    <Card key={farm.id} className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => handleFarmClick(farm.id)}>
                      <CardHeader className="pb-2">
                        <CardTitle>{farm.name}</CardTitle>
                        <CardDescription>{farm.location || "Sin ubicación"}</CardDescription>
                      </CardHeader>
                      <CardContent className="pb-2">
                        <div className="flex justify-between items-center text-sm">
                          <span>Capacidad:</span>
                          <span className="font-medium">{farm.henCapacity || "No especificada"}</span>
                        </div>
                      </CardContent>
                      <CardFooter className="flex justify-between items-center pt-2">
                        <span className="text-xs text-muted-foreground">
                          Creada: {new Date(farm.createdAt).toLocaleDateString()}
                        </span>
                        <ChevronRight className="h-5 w-5 text-primary" />
                      </CardFooter>
                    </Card>
                  ))
                )}
              </div>
            </TabsContent>
            
            <TabsContent value="financials">
              <div className="space-y-4">
                <Card>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle>Proyecciones financieras</CardTitle>
                        <CardDescription>Controla los ingresos y gastos de tus granjas</CardDescription>
                      </div>
                      <BarChart className="h-10 w-10 text-primary/50" />
                    </div>
                  </CardHeader>
                  <CardContent>
                    {!farms || farms.length === 0 ? (
                      <div className="text-center py-8">
                        <p className="text-muted-foreground mb-4">No tienes granjas registradas para gestionar proyecciones financieras</p>
                        <Button onClick={handleCreateFarm}>Crear granja</Button>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        <p className="text-sm text-muted-foreground">
                          Selecciona una granja para administrar sus proyecciones financieras:
                        </p>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                          {farms.map((farm) => (
                            <Card key={farm.id} className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => navigate(`/farms/${farm.id}/financials`)}>
                              <CardContent className="flex justify-between items-center p-4">
                                <div>
                                  <h3 className="font-medium">{farm.name}</h3>
                                  <p className="text-sm text-muted-foreground">{farm.location || "Sin ubicación"}</p>
                                </div>
                                <ChevronRight className="h-5 w-5 text-primary" />
                              </CardContent>
                            </Card>
                          ))}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            
            <TabsContent value="weights">
              <div className="space-y-4">
                <Card>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle>Registro de peso</CardTitle>
                        <CardDescription>Seguimiento del peso de tus aves</CardDescription>
                      </div>
                      <Weight className="h-10 w-10 text-primary/50" />
                    </div>
                  </CardHeader>
                  <CardContent>
                    {!farms || farms.length === 0 ? (
                      <div className="text-center py-8">
                        <p className="text-muted-foreground mb-4">No tienes granjas registradas para gestionar registros de peso</p>
                        <Button onClick={handleCreateFarm}>Crear granja</Button>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        <p className="text-sm text-muted-foreground">
                          Selecciona una granja para administrar sus registros de peso:
                        </p>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                          {farms.map((farm) => (
                            <Card key={farm.id} className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => navigate(`/farms/${farm.id}/weights`)}>
                              <CardContent className="flex justify-between items-center p-4">
                                <div>
                                  <h3 className="font-medium">{farm.name}</h3>
                                  <p className="text-sm text-muted-foreground">{farm.location || "Sin ubicación"}</p>
                                </div>
                                <ChevronRight className="h-5 w-5 text-primary" />
                              </CardContent>
                            </Card>
                          ))}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            
            <TabsContent value="health">
              <div className="space-y-4">
                <Card>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle>Registro de sanidad</CardTitle>
                        <CardDescription>Control de la salud de tus aves</CardDescription>
                      </div>
                      <Activity className="h-10 w-10 text-primary/50" />
                    </div>
                  </CardHeader>
                  <CardContent>
                    {!farms || farms.length === 0 ? (
                      <div className="text-center py-8">
                        <p className="text-muted-foreground mb-4">No tienes granjas registradas para gestionar registros de sanidad</p>
                        <Button onClick={handleCreateFarm}>Crear granja</Button>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        <p className="text-sm text-muted-foreground">
                          Selecciona una granja para administrar sus registros de sanidad:
                        </p>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                          {farms.map((farm) => (
                            <Card key={farm.id} className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => navigate(`/farms/${farm.id}/health`)}>
                              <CardContent className="flex justify-between items-center p-4">
                                <div>
                                  <h3 className="font-medium">{farm.name}</h3>
                                  <p className="text-sm text-muted-foreground">{farm.location || "Sin ubicación"}</p>
                                </div>
                                <ChevronRight className="h-5 w-5 text-primary" />
                              </CardContent>
                            </Card>
                          ))}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            
            <TabsContent value="eggs">
              <div className="space-y-4">
                <Card>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle>Producción de huevos</CardTitle>
                        <CardDescription>Registra y analiza la producción de huevos</CardDescription>
                      </div>
                      <Egg className="h-10 w-10 text-primary/50" />
                    </div>
                  </CardHeader>
                  <CardContent>
                    {!farms || farms.length === 0 ? (
                      <div className="text-center py-8">
                        <p className="text-muted-foreground mb-4">No tienes granjas registradas para gestionar la producción de huevos</p>
                        <Button onClick={handleCreateFarm}>Crear granja</Button>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        <p className="text-sm text-muted-foreground">
                          Selecciona una granja para administrar su producción de huevos:
                        </p>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                          {farms.map((farm) => (
                            <Card key={farm.id} className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => navigate(`/farms/${farm.id}/eggs`)}>
                              <CardContent className="flex justify-between items-center p-4">
                                <div>
                                  <h3 className="font-medium">{farm.name}</h3>
                                  <p className="text-sm text-muted-foreground">{farm.location || "Sin ubicación"}</p>
                                </div>
                                <ChevronRight className="h-5 w-5 text-primary" />
                              </CardContent>
                            </Card>
                          ))}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>

      {/* Footer */}
      <footer className="py-4 px-6 border-t border-border bg-background">
        <div className="text-center text-sm text-muted-foreground">
          Curso exclusivo, prohibida su distribución
        </div>
      </footer>
    </div>
  );
}
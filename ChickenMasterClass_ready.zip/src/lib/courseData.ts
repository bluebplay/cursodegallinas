export interface Module {
  id: number;
  title: string;
  description: string;
  content: string;
  pdfPath: string;
  videoUrl?: string | null;
  videoTitle?: string | null;
  orderIndex?: number;
  isVideoComplement?: boolean | null;
  createdAt?: Date | string;
  updatedAt?: Date | string;
}

export const modules: Module[] = [
  {
    id: 1,
    title: "El negocio de los huevos de oro",
    description: "Introducción al negocio de gallinas ponedoras, ventajas y consideraciones iniciales.",
    content: "El negocio de las gallinas ponedoras representa una de las actividades agropecuarias más accesibles y constantes en rentabilidad. Su éxito radica en la alta demanda de huevos, la relativa facilidad de manejo de las aves y la posibilidad de iniciar con una inversión modesta. A diferencia de otros modelos productivos, la avicultura de postura puede desarrollarse en espacios pequeños y escalar progresivamente conforme crecen los ingresos.\n\nLos huevos son un alimento básico en prácticamente todos los hogares. Esto garantiza una demanda constante que no depende de temporadas. Además, es un producto fácil de transportar, almacenar y vender tanto a nivel local como regional. A esto se suma que los huevos tienen un excelente valor nutricional y un precio accesible, lo que refuerza su presencia en la dieta diaria.\n\nUna gallina en plena etapa de postura puede producir entre 5 y 6 huevos por semana, lo que equivale a más de 250 huevos al año. Esto permite que incluso un pequeño lote de 20 a 30 aves pueda generar una producción interesante para autoconsumo y venta. Al mismo tiempo, el alimento requerido por cada gallina es moderado y se puede complementar con insumos locales, lo que reduce costos.",
    pdfPath: "attached_assets/MODULO_1.pdf",
    videoUrl: "https://www.youtube.com/embed/cn9Nb_KEam8",
    videoTitle: "Introducción al Curso de Gallinas Ponedoras"
  },
  {
    id: 2,
    title: "Elegir bien para producir mejor",
    description: "Cómo seleccionar las razas y cantidad adecuada de gallinas para tu proyecto.",
    content: "La elección de las gallinas es uno de los factores más determinantes en el éxito de una granja ponedora. No todas las aves tienen el mismo potencial de postura ni se comportan igual bajo diferentes condiciones. Elegir una raza adecuada, definir la cantidad correcta y seleccionar aves sanas desde el inicio puede marcar la diferencia entre una producción eficiente y un negocio con pérdidas.\n\nExisten dos grandes categorías de gallinas ponedoras: las industriales y las rústicas. Las industriales, como la Hy-Line Brown, Isa Brown o Lohmann, han sido seleccionadas genéticamente para producir una alta cantidad de huevos en un período corto. Estas gallinas requieren un manejo técnico más estricto, buena alimentación y cuidados constantes, pero a cambio ofrecen una postura que puede superar los 300 huevos al año.\n\nPor otro lado, las razas rústicas o criollas, como la Rhode Island Red, Plymouth Rock o Sussex, son aves más resistentes, que se adaptan a condiciones variables y se alimentan bien con recursos locales. Aunque su producción de huevos es menor, suelen vivir más tiempo, enferman menos y requieren menos insumos industriales, lo que las convierte en una opción atractiva para pequeños productores o sistemas de libre pastoreo.",
    pdfPath: "attached_assets/MODULO_2.pdf",
    videoUrl: "https://www.youtube.com/embed/2H_VwFzI9pQ",
    videoTitle: "Selección de Razas de Gallinas Ponedoras"
  },
  {
    id: 3,
    title: "Construcción inteligente: gallineros económicos y funcionales",
    description: "Diseño y construcción de gallineros prácticos, económicos y adaptados a diferentes climas.",
    content: "El gallinero es el núcleo físico de cualquier proyecto avícola. Su diseño, construcción y mantenimiento tienen un impacto directo en la salud de las gallinas y, por tanto, en la productividad de la granja. No se trata de construir una estructura costosa, sino de crear un espacio funcional, higiénico y adaptado a las condiciones del entorno.\n\nEl primer paso es elegir el lugar correcto. El terreno debe estar bien drenado, lejos de zonas encharcadas o propensas a inundaciones. Idealmente debe ubicarse en un área tranquila, protegida del viento fuerte y con buena exposición solar en la mañana. Esto permite que las aves se mantengan activas desde temprano y ayuda a secar la humedad del suelo.\n\nLa orientación del gallinero también importa. Lo ideal es que reciba sol en la mañana y sombra en la tarde. Una orientación este-oeste con aberturas hacia el sur permite una mejor ventilación y control térmico. En climas calurosos, se deben evitar techos de lámina sin protección, ya que incrementan la temperatura interna y generan estrés en las gallinas.",
    pdfPath: "attached_assets/MODULO_3.pdf",
    videoUrl: "https://www.youtube.com/embed/tfht-6sj1cA",
    videoTitle: "Construcción de Gallineros Eficientes"
  },
  {
    id: 4,
    title: "Alimentación eficiente: dieta balanceada y económica",
    description: "Estrategias para alimentar a tus gallinas de forma nutritiva y económica.",
    content: "La alimentación es uno de los pilares fundamentales en la producción de huevos. Una gallina bien alimentada es una gallina productiva. Sin embargo, muchos pequeños productores creen que para alimentar correctamente es necesario gastar grandes sumas en alimentos comerciales. En este módulo descubrirás cómo ofrecer una dieta equilibrada sin afectar tu bolsillo.\n\nUna ponedora necesita una dieta con balance adecuado de energía, proteína, calcio y otros minerales para mantener su postura y salud. La carencia de cualquiera de estos elementos puede generar una caída en la producción, problemas en la calidad del cascarón o incluso enfermedades. Por eso, no se trata solo de alimentar, sino de nutrir con intención.\n\nEl alimento representa entre el 60% y el 70% de los costos de producción. Saber cómo reducir ese gasto sin comprometer la calidad es clave para aumentar la rentabilidad. Una estrategia efectiva es combinar alimento comercial con ingredientes locales, residuos agrícolas o preparados caseros formulados con conocimiento.",
    pdfPath: "attached_assets/MODULO_4.pdf",
    videoUrl: "https://www.youtube.com/embed/BW75iD6BWas",
    videoTitle: "Alimentación Balanceada para Gallinas Ponedoras"
  },
  {
    id: 5,
    title: "Salud y prevención: claves para una producción estable",
    description: "Cómo prevenir enfermedades y mantener un lote de gallinas sano.",
    content: "La salud de las gallinas ponedoras es un factor crítico en la continuidad y estabilidad de la producción. Una ave enferma reduce su postura, afecta al resto del lote y puede generar pérdidas considerables. Prevenir es más rentable que curar, y este módulo se enfoca en darte las herramientas para lograrlo.\n\nLas enfermedades más comunes en gallinas ponedoras incluyen la coccidiosis, viruela aviar, enfermedad de Newcastle, bronquitis infecciosa y colibacilosis. Estas afectan directamente la producción de huevos, el apetito, la movilidad e incluso la supervivencia del animal. Algunas son virales, otras bacterianas o parasitarias, pero todas pueden prevenirse con buenas prácticas de manejo.\n\nLa higiene es la primera barrera de defensa. Un gallinero limpio y seco reduce la carga microbiana del ambiente. Se recomienda retirar el estiércol semanalmente, cambiar la cama cada 7 a 10 días y realizar una desinfección general mensual. El uso de cal, vinagre blanco o productos especializados ayuda a mantener el ambiente libre de patógenos.",
    pdfPath: "attached_assets/MODULO_5.pdf",
    videoUrl: "https://www.youtube.com/embed/X3wopqky5iw",
    videoTitle: "Salud y Prevención en Aves de Postura"
  },
  {
    id: 6,
    title: "Cosecha y cuidado: del gallinero al cliente",
    description: "Recolección, manejo y conservación de huevos para asegurar calidad y durabilidad.",
    content: "Una vez que las gallinas comienzan a poner huevos, el siguiente paso clave en el negocio es saber cómo manejarlos adecuadamente. La forma en que se recolectan, se limpian y se almacenan influye directamente en la calidad del producto final y en la satisfacción del cliente. Este módulo se centra en las mejores prácticas para llevar el huevo desde el nido hasta el consumidor sin pérdidas ni problemas.\n\nEl momento ideal para recolectar los huevos es temprano por la mañana, entre las 7:00 y 10:00 am. La mayoría de las gallinas ponen sus huevos a primera hora del día, por lo que recogerlos pronto evita que se ensucien, rompan o sean picoteados por otras aves. Si el lote es grande, conviene hacer una segunda ronda de recolección por la tarde.\n\nUsa una canasta o recipiente con fondo acolchado para recoger los huevos. Evita el uso de bolsas o superficies duras, ya que el contacto constante entre los huevos puede dañarlos. Es importante manipularlos con cuidado, sin golpes ni presiones excesivas. Un huevo roto representa una pérdida y una posible fuente de contaminación.",
    pdfPath: "attached_assets/MODULO_6.pdf",
    videoUrl: "https://www.youtube.com/embed/E4Bnc50YEhs",
    videoTitle: "Recolección y Manejo de Huevos de Calidad"
  },
  {
    id: 7,
    title: "Vender con inteligencia: precios, canales y clientes fieles",
    description: "Estrategias de comercialización y fidelización de clientes para tu negocio.",
    content: "Tener una buena producción de huevos es solo la mitad del camino. La otra parte es saber venderlos correctamente para que el negocio sea sostenible. En este módulo aprenderás cómo fijar precios justos, elegir los mejores canales de venta y crear una base sólida de clientes fieles.\n\nEl primer paso es entender tus costos. Para saber cuánto cobrar por cada huevo o docena, necesitas sumar todos los gastos relacionados: alimento, mantenimiento del gallinero, medicamentos, reemplazo de gallinas, empaques, transporte y tu propio tiempo. Luego, divide esa cifra entre el número de huevos producidos en el mismo periodo.\n\nPor ejemplo, si tu gasto mensual total es de $2,400 y produces 800 huevos al mes, cada huevo te cuesta $3.00. Si deseas un margen de ganancia del 25%, deberías vender cada huevo a $3.75. Esta fórmula te permite tener un precio rentable sin afectar la competitividad.",
    pdfPath: "attached_assets/MODULO_7.pdf",
    videoUrl: "https://www.youtube.com/embed/ofYYhL8ENb8",
    videoTitle: "Estrategias de Comercialización para Productores Avícolas"
  },
  {
    id: 8,
    title: "Crecimiento inteligente: reinversión, diversificación y valor agregado",
    description: "Cómo hacer crecer tu negocio de forma sostenible y rentable.",
    content: "Cuando un emprendimiento comienza a dar resultados, el siguiente paso lógico es pensar en su crecimiento. Sin embargo, crecer no significa hacerlo de forma desordenada ni endeudarse para lograrlo. En este módulo exploraremos cómo reinvertir de forma inteligente, qué productos adicionales puedes desarrollar y cómo darle más valor a lo que ya produces.\n\nLa reinversión es clave para consolidar cualquier proyecto. No se trata de gastar todas las ganancias, sino de destinar una parte a mejorar el gallinero, ampliar el lote de gallinas, renovar implementos o capacitarte. Un buen porcentaje de reinversión inicial puede ir del 20% al 40% de las utilidades, dependiendo del estado del negocio.\n\nAntes de reinvertir, analiza qué área necesita más atención. Si el gallinero está deteriorado, prioriza la infraestructura. Si te falta espacio para nuevas aves, invierte en ampliación. Si has detectado que los clientes valoran más la presentación, enfoca los recursos en empaques, etiquetas o imagen de marca.",
    pdfPath: "attached_assets/MODULO_8.pdf"
  },
  {
    id: 9,
    title: "Organización práctica: finanzas y crecimiento paso a paso",
    description: "Cómo llevar registro de tu producción y finanzas para crecer ordenadamente.",
    content: "La organización financiera es uno de los aspectos más olvidados por los pequeños productores, pero también uno de los más importantes. Llevar un control de ingresos, gastos, producción y reinversión es fundamental para tomar decisiones acertadas. En este módulo aprenderás cómo hacerlo de manera sencilla y efectiva.\n\nEmpecemos con lo básico: registrar los ingresos. Cada venta que realices debe anotarse, ya sea en una libreta, un archivo de Excel o una aplicación móvil. Anota el día, el cliente, la cantidad de huevos vendidos, el precio por unidad y el total cobrado. Esto te permitirá saber cuánto estás generando realmente y cuándo lo estás haciendo.\n\nLuego, anota todos los gastos relacionados con tu producción. Esto incluye alimento, medicamentos, gallinas nuevas, mantenimiento del gallinero, empaque, transporte, herramientas y cualquier otro insumo. Si lo pagas con dinero del negocio, debe registrarse. Es importante que los registros sean completos, aunque el monto parezca pequeño.",
    pdfPath: "attached_assets/MODULO_9.pdf"
  }
];

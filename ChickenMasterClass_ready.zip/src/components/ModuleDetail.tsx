import { useState } from "react";
import { CommonModule } from "@/hooks/use-common-types";
import { Button } from "@/components/ui/button";
import { ArrowLeft, BookOpen, Download, Eye, Video } from "lucide-react";
import VideoPlayer from "@/components/VideoPlayer";

interface ModuleDetailProps {
  module: CommonModule;
  onBack: () => void;
  onView: () => void;
  onViewVideo?: () => void;
}

export default function ModuleDetail({ module, onBack, onView, onViewVideo }: ModuleDetailProps) {
  const handleDownload = async () => {
    try {
      const response = await fetch(`/api/download/${module.id}`);
      if (!response.ok) throw new Error('Download failed');
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Modulo_${module.id}_${module.title.replace(/\s+/g, '_')}.pdf`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (error) {
      console.error('Error downloading file:', error);
    }
  };

  // Determinar si este es un módulo de video o un módulo regular con video complementario
  const isVideoModule = module.isVideoComplement === true;

  return (
    <div className="bg-white rounded-lg shadow-lg p-6 fade-in border border-neutral-200">
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-6 gap-4">
        <h2 className="text-2xl md:text-3xl font-heading font-bold gradient-heading">
          {isVideoModule ? "Video" : "Módulo"} {module.id}: {module.title}
        </h2>
        <Button
          variant="ghost" 
          onClick={onBack}
          className="flex items-center text-primary hover:text-accent transition-all duration-300"
        >
          <ArrowLeft className="h-4 w-4 mr-2" /> Volver a {isVideoModule ? "videos" : "módulos"}
        </Button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        {/* Botón para ver PDF */}
        <Button 
          onClick={onView}
          className="btn-primary h-16 text-base"
        >
          <Eye className="h-5 w-5 mr-3" /> Ver {isVideoModule ? "Material" : "Módulo"} en Libro Digital
        </Button>
        
        {/* Botón para descargar PDF */}
        <Button 
          onClick={handleDownload}
          variant="outline"
          className="h-16 text-base border-2 border-primary text-primary hover:bg-primary hover:text-white transition-all duration-300 flex items-center justify-center"
        >
          <Download className="h-5 w-5 mr-3" /> Descargar PDF
        </Button>
        
        {/* Botón para ver video */}
        <Button 
          onClick={onViewVideo}
          disabled={!module.videoUrl || !onViewVideo}
          className={`h-16 text-base flex items-center justify-center transition-all duration-300 ${
            module.videoUrl && onViewVideo
              ? isVideoModule 
                ? "bg-gradient-to-r from-indigo-600 to-violet-600 text-white hover:from-indigo-700 hover:to-violet-700"
                : "bg-accent text-black hover:bg-accent/80" 
              : "bg-gray-200 text-gray-500 cursor-not-allowed"
          }`}
        >
          <Video className="h-5 w-5 mr-3" /> 
          {module.videoUrl ? 
            isVideoModule ? "Ver Video Principal" : "Ver Video Complementario" 
            : "Video no disponible"}
        </Button>
      </div>
      
      {/* Contenido del módulo */}
      <div className="bg-neutral-50 rounded-lg p-6 border border-neutral-200 shadow-inner">
        <h3 className="text-xl font-heading font-semibold text-primary mb-4">
          {isVideoModule ? "Descripción del Video" : "Resumen del Módulo"}
        </h3>
        <div className="prose max-w-none">
          <div className="text-gray-700 leading-relaxed">
            {module.content.split('\n').map((paragraph, index) => (
              <p key={index} className="mb-4">
                {paragraph}
              </p>
            ))}
          </div>
        </div>
      </div>
      
      {/* Aviso de video complementario si existe y no es un módulo de video */}
      {module.videoUrl && !isVideoModule && (
        <div className="mt-6 bg-amber-50 p-4 rounded-lg border border-amber-200">
          <div className="flex items-start">
            <Video className="h-5 w-5 mr-3 text-amber-600 mt-1 flex-shrink-0" />
            <div>
              <h4 className="font-heading font-medium text-amber-800 mb-1">
                Video complementario disponible
              </h4>
              <p className="text-amber-700 text-sm">
                Este módulo incluye un video adicional para reforzar tu aprendizaje. 
                Haz clic en "Ver Video Complementario" para visualizarlo.
              </p>
            </div>
          </div>
        </div>
      )}
      
      {/* Decorative element */}
      <div className="mt-8 flex justify-center">
        <div className="w-16 h-1 bg-gradient-to-r from-primary to-secondary rounded-full"></div>
      </div>
    </div>
  );
}

import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { CommonModule } from "@/hooks/use-common-types";
import { X, LogOut, Egg, BookOpenCheck, Video, Database, User } from "lucide-react";
import { cn } from "@/lib/utils";

interface MobileMenuProps {
  isOpen: boolean;
  onClose: () => void;
  onModuleSelect: (module: CommonModule) => void;
  onLogout: () => void;
}

export default function MobileMenu({ isOpen, onClose, onModuleSelect, onLogout }: MobileMenuProps) {
  const [location, navigate] = useLocation();
  const { user: authUser } = useAuth();
  
  if (!isOpen) return null;

  const navigateAndClose = (path: string) => {
    navigate(path);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 md:hidden">
      <div className="bg-white w-72 h-full overflow-y-auto shadow-xl animate-slide-in-right">
        <div className="bg-gradient-to-r from-primary to-secondary text-white p-5">
          <div className="flex justify-between items-center">
            <div className="flex items-center">
              <Egg className="h-5 w-5 mr-2" />
              <h2 className="font-heading font-medium">Curso de Gallinas Ponedoras</h2>
            </div>
            <button onClick={onClose} className="text-white hover:text-accent transition-colors">
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>
        
        <div className="p-4">
          <h3 className="text-sm uppercase tracking-wider text-gray-500 mb-3 font-medium">Navegación</h3>
          
          <ul className="space-y-2 mb-6">
            <li>
              <button
                onClick={() => navigateAndClose("/")}
                className="w-full flex items-center py-3 px-3 rounded-md hover:bg-gray-100 text-gray-700 hover:text-primary transition-all duration-200"
              >
                <BookOpenCheck className="h-5 w-5 mr-3 text-primary" />
                <span className="font-medium">Módulos del Curso</span>
              </button>
            </li>
            
            <li>
              <button
                onClick={() => navigateAndClose("/videos")}
                className="w-full flex items-center py-3 px-3 rounded-md hover:bg-gray-100 text-gray-700 hover:text-primary transition-all duration-200"
              >
                <Video className="h-5 w-5 mr-3 text-primary" />
                <span className="font-medium">Videos Complementarios</span>
              </button>
            </li>
            
            {authUser ? (
              <>
                <li>
                  <button
                    onClick={() => navigateAndClose("/dashboard")}
                    className="w-full flex items-center py-3 px-3 rounded-md hover:bg-gray-100 text-gray-700 hover:text-primary transition-all duration-200"
                  >
                    <Database className="h-5 w-5 mr-3 text-primary" />
                    <span className="font-medium">Registros de Granja</span>
                  </button>
                </li>
                
                <li>
                  <button
                    onClick={() => navigateAndClose("/profile")}
                    className="w-full flex items-center py-3 px-3 rounded-md hover:bg-gray-100 text-gray-700 hover:text-primary transition-all duration-200"
                  >
                    <User className="h-5 w-5 mr-3 text-primary" />
                    <span className="font-medium">Mi Perfil</span>
                  </button>
                </li>
              </>
            ) : (
              <li>
                <button
                  onClick={() => navigateAndClose("/auth")}
                  className="w-full flex items-center py-3 px-3 rounded-md hover:bg-gray-100 text-gray-700 hover:text-primary transition-all duration-200"
                >
                  <User className="h-5 w-5 mr-3 text-primary" />
                  <span className="font-medium">Iniciar Sesión</span>
                </button>
              </li>
            )}
          </ul>
          
          <div className="border-t border-gray-200 pt-4 mt-4">
            <button
              onClick={onLogout}
              className="w-full flex items-center py-3 px-3 rounded-md hover:bg-gray-100 text-gray-700 hover:text-red-500 transition-all duration-200"
            >
              <LogOut className="h-5 w-5 mr-3" />
              <span className="font-medium">Cerrar Sesión</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

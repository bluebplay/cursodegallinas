import { useState, useEffect } from "react";
import { CommonModule } from "@/hooks/use-common-types";
import { Button } from "@/components/ui/button";
import { X, ChevronLeft, ChevronRight, BookOpen } from "lucide-react";
import { Document, Page, pdfjs } from "react-pdf";

// Set the worker source for PDF.js
pdfjs.GlobalWorkerOptions.workerSrc = `//unpkg.com/pdfjs-dist@${pdfjs.version}/build/pdf.worker.min.js`;

interface PdfViewerProps {
  module: CommonModule;
  onClose: () => void;
}

export default function PdfViewer({ module, onClose }: PdfViewerProps) {
  const [numPages, setNumPages] = useState<number | null>(null);
  const [pageNumber, setPageNumber] = useState<number>(1);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isBookOpen, setIsBookOpen] = useState<boolean>(false);

  const pdfUrl = `/api/pdf/${module.id}`;

  function onDocumentLoadSuccess({ numPages }: { numPages: number }) {
    setNumPages(numPages);
    setIsLoading(false);
    // Auto-open the book after loading
    setTimeout(() => {
      setIsBookOpen(true);
    }, 300);
  }

  const goToPreviousPage = () => {
    if (pageNumber > 1) {
      setPageNumber(pageNumber - 1);
    }
  };

  const goToNextPage = () => {
    if (numPages && pageNumber < numPages) {
      setPageNumber(pageNumber + 1);
    }
  };

  return (
    <div className="fade-in">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-heading font-bold text-gray-800 gradient-heading">
          Módulo {module.id}: {module.title}
        </h2>
        <Button
          variant="ghost"
          onClick={onClose}
          className="flex items-center text-primary hover:text-accent transition duration-300"
        >
          <X className="h-4 w-4 mr-2" /> Cerrar
        </Button>
      </div>
      
      <div className="book-container">
        <div className={`book ${isBookOpen ? 'open' : ''}`}>
          {/* Book cover */}
          <div className="book-cover">
            <div className="book-cover-title">
              <BookOpen className="h-12 w-12 mx-auto mb-4 text-white opacity-80" />
              <h3>Módulo {module.id}</h3>
              <p className="mt-2 text-xl">{module.title}</p>
              <p className="text-sm mt-6 opacity-80">Curso de Gallinas Ponedoras</p>
            </div>
          </div>
          
          {/* Book content */}
          <div className="book-content">
            <div className="page-turner page-turner-left" onClick={goToPreviousPage}>
              {pageNumber > 1 && (
                <div className="page-turner-icon">
                  <ChevronLeft className="h-4 w-4" />
                </div>
              )}
            </div>
            
            <div className="page">
              <div className="page-content no-scrollbar">
                {isLoading ? (
                  <div className="flex items-center justify-center h-full w-full">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
                  </div>
                ) : (
                  <Document
                    file={pdfUrl}
                    onLoadSuccess={onDocumentLoadSuccess}
                    onLoadError={(error) => console.error("Error loading PDF:", error)}
                    loading={
                      <div className="flex items-center justify-center h-full w-full">
                        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
                      </div>
                    }
                  >
                    <Page 
                      pageNumber={pageNumber} 
                      renderTextLayer={false}
                      renderAnnotationLayer={false}
                      width={Math.min(window.innerWidth - 80, 800)}
                    />
                  </Document>
                )}
                <div className="page-number page-number-right">{pageNumber}</div>
              </div>
            </div>
            
            <div className="page-turner page-turner-right" onClick={goToNextPage}>
              {numPages && pageNumber < numPages && (
                <div className="page-turner-icon">
                  <ChevronRight className="h-4 w-4" />
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      
      {/* Page navigation controls */}
      <div className="flex justify-between items-center p-4 bg-gray-100 border rounded-lg mt-4 shadow-sm">
        <Button
          onClick={goToPreviousPage}
          disabled={pageNumber <= 1}
          className="btn-primary"
        >
          <ChevronLeft className="h-4 w-4 mr-2" /> Anterior
        </Button>
        <span className="text-gray-700 font-medium">
          Página {pageNumber} de {numPages || '...'}
        </span>
        <Button
          onClick={goToNextPage}
          disabled={numPages === null || pageNumber >= numPages}
          className="btn-primary"
        >
          Siguiente <ChevronRight className="h-4 w-4 ml-2" />
        </Button>
      </div>
    </div>
  );
}

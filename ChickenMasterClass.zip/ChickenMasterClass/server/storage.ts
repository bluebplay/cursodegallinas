import { 
  User, InsertUser, 
  Module, InsertModule,
  UserProgress, InsertUserProgress,
  Farm, InsertFarm,
  FinancialProjection, InsertFinancialProjection,
  WeightRecord, InsertWeightRecord,
  HealthRecord, InsertHealthRecord,
  EggProduction, InsertEggProduction,
  users, modules, userProgress,
  farms, financialProjections, weightRecords, healthRecords, eggProduction
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { Pool } from "@neondatabase/serverless";

export interface IStorage {
  // Sesión
  sessionStore: session.Store;
  
  // Usuarios
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Módulos
  getModules(): Promise<Module[]>;
  getModuleById(id: number): Promise<Module | undefined>;
  getVideoModules(): Promise<Module[]>;
  
  // Progreso del usuario
  getUserProgress(userId: number): Promise<UserProgress[]>;
  markModuleAsCompleted(userId: number, moduleId: number): Promise<UserProgress>;
  
  // Granjas
  getUserFarms(userId: number): Promise<Farm[]>;
  getFarmById(id: number, userId: number): Promise<Farm | undefined>;
  createFarm(farm: InsertFarm): Promise<Farm>;
  updateFarm(id: number, farm: Partial<InsertFarm>): Promise<Farm | undefined>;
  deleteFarm(id: number, userId: number): Promise<boolean>;
  
  // Proyecciones financieras
  getFinancialProjections(farmId: number): Promise<FinancialProjection[]>;
  getFinancialProjectionById(id: number, farmId: number): Promise<FinancialProjection | undefined>;
  createFinancialProjection(projection: InsertFinancialProjection): Promise<FinancialProjection>;
  updateFinancialProjection(id: number, projection: Partial<InsertFinancialProjection>): Promise<FinancialProjection | undefined>;
  deleteFinancialProjection(id: number, farmId: number): Promise<boolean>;
  
  // Registros de peso
  getWeightRecords(farmId: number): Promise<WeightRecord[]>;
  getWeightRecordById(id: number, farmId: number): Promise<WeightRecord | undefined>;
  createWeightRecord(record: InsertWeightRecord): Promise<WeightRecord>;
  updateWeightRecord(id: number, record: Partial<InsertWeightRecord>): Promise<WeightRecord | undefined>;
  deleteWeightRecord(id: number, farmId: number): Promise<boolean>;
  
  // Registros de salud
  getHealthRecords(farmId: number): Promise<HealthRecord[]>;
  getHealthRecordById(id: number, farmId: number): Promise<HealthRecord | undefined>;
  createHealthRecord(record: InsertHealthRecord): Promise<HealthRecord>;
  updateHealthRecord(id: number, record: Partial<InsertHealthRecord>): Promise<HealthRecord | undefined>;
  deleteHealthRecord(id: number, farmId: number): Promise<boolean>;
  
  // Producción de huevos
  getEggProduction(farmId: number): Promise<EggProduction[]>;
  getEggProductionById(id: number, farmId: number): Promise<EggProduction | undefined>;
  createEggProduction(record: InsertEggProduction): Promise<EggProduction>;
  updateEggProduction(id: number, record: Partial<InsertEggProduction>): Promise<EggProduction | undefined>;
  deleteEggProduction(id: number, farmId: number): Promise<boolean>;
}

const PostgresSessionStore = connectPg(session);
const pgPool = new Pool({ 
  connectionString: process.env.DATABASE_URL as string 
});

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;
  
  constructor() {
    this.sessionStore = new PostgresSessionStore({ 
      pool: pgPool, 
      createTableIfMissing: true 
    });
  }
  
  // Usuarios
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }
  
  // Módulos
  async getModules(): Promise<Module[]> {
    return db.select().from(modules).orderBy(modules.orderIndex);
  }
  
  async getModuleById(id: number): Promise<Module | undefined> {
    const [module] = await db.select().from(modules).where(eq(modules.id, id));
    return module;
  }
  
  async getVideoModules(): Promise<Module[]> {
    return db.select().from(modules).where(eq(modules.isVideoComplement, true)).orderBy(modules.orderIndex);
  }
  
  // Progreso del usuario
  async getUserProgress(userId: number): Promise<UserProgress[]> {
    return db.select().from(userProgress).where(eq(userProgress.userId, userId));
  }
  
  async markModuleAsCompleted(userId: number, moduleId: number): Promise<UserProgress> {
    const [existingProgress] = await db
      .select()
      .from(userProgress)
      .where(and(
        eq(userProgress.userId, userId),
        eq(userProgress.moduleId, moduleId)
      ));
    
    if (existingProgress) {
      const [updated] = await db
        .update(userProgress)
        .set({ 
          completed: true, 
          lastAccessedAt: new Date() 
        })
        .where(eq(userProgress.id, existingProgress.id))
        .returning();
      return updated;
    } else {
      const [newProgress] = await db
        .insert(userProgress)
        .values({
          userId,
          moduleId,
          completed: true,
          lastAccessedAt: new Date()
        })
        .returning();
      return newProgress;
    }
  }
  
  // Granjas
  async getUserFarms(userId: number): Promise<Farm[]> {
    return db
      .select()
      .from(farms)
      .where(eq(farms.userId, userId))
      .orderBy(desc(farms.createdAt));
  }
  
  async getFarmById(id: number, userId: number): Promise<Farm | undefined> {
    const [farm] = await db
      .select()
      .from(farms)
      .where(and(
        eq(farms.id, id),
        eq(farms.userId, userId)
      ));
    return farm;
  }
  
  async createFarm(farm: InsertFarm): Promise<Farm> {
    const [newFarm] = await db
      .insert(farms)
      .values(farm)
      .returning();
    return newFarm;
  }
  
  async updateFarm(id: number, farm: Partial<InsertFarm>): Promise<Farm | undefined> {
    const [updated] = await db
      .update(farms)
      .set({
        ...farm,
        updatedAt: new Date()
      })
      .where(eq(farms.id, id))
      .returning();
    return updated;
  }
  
  async deleteFarm(id: number, userId: number): Promise<boolean> {
    const result = await db
      .delete(farms)
      .where(and(
        eq(farms.id, id),
        eq(farms.userId, userId)
      ));
    return !!result;
  }
  
  // Proyecciones financieras
  async getFinancialProjections(farmId: number): Promise<FinancialProjection[]> {
    return db
      .select()
      .from(financialProjections)
      .where(eq(financialProjections.farmId, farmId))
      .orderBy(desc(financialProjections.month));
  }
  
  async getFinancialProjectionById(id: number, farmId: number): Promise<FinancialProjection | undefined> {
    const [projection] = await db
      .select()
      .from(financialProjections)
      .where(and(
        eq(financialProjections.id, id),
        eq(financialProjections.farmId, farmId)
      ));
    return projection;
  }
  
  async createFinancialProjection(projection: InsertFinancialProjection): Promise<FinancialProjection> {
    const [newProjection] = await db
      .insert(financialProjections)
      .values(projection)
      .returning();
    return newProjection;
  }
  
  async updateFinancialProjection(id: number, projection: Partial<InsertFinancialProjection>): Promise<FinancialProjection | undefined> {
    const [updated] = await db
      .update(financialProjections)
      .set({
        ...projection,
        updatedAt: new Date()
      })
      .where(eq(financialProjections.id, id))
      .returning();
    return updated;
  }
  
  async deleteFinancialProjection(id: number, farmId: number): Promise<boolean> {
    const result = await db
      .delete(financialProjections)
      .where(and(
        eq(financialProjections.id, id),
        eq(financialProjections.farmId, farmId)
      ));
    return !!result;
  }
  
  // Registros de peso
  async getWeightRecords(farmId: number): Promise<WeightRecord[]> {
    return db
      .select()
      .from(weightRecords)
      .where(eq(weightRecords.farmId, farmId))
      .orderBy(desc(weightRecords.recordDate));
  }
  
  async getWeightRecordById(id: number, farmId: number): Promise<WeightRecord | undefined> {
    const [record] = await db
      .select()
      .from(weightRecords)
      .where(and(
        eq(weightRecords.id, id),
        eq(weightRecords.farmId, farmId)
      ));
    return record;
  }
  
  async createWeightRecord(record: InsertWeightRecord): Promise<WeightRecord> {
    const [newRecord] = await db
      .insert(weightRecords)
      .values(record)
      .returning();
    return newRecord;
  }
  
  async updateWeightRecord(id: number, record: Partial<InsertWeightRecord>): Promise<WeightRecord | undefined> {
    const [updated] = await db
      .update(weightRecords)
      .set({
        ...record,
        updatedAt: new Date()
      })
      .where(eq(weightRecords.id, id))
      .returning();
    return updated;
  }
  
  async deleteWeightRecord(id: number, farmId: number): Promise<boolean> {
    const result = await db
      .delete(weightRecords)
      .where(and(
        eq(weightRecords.id, id),
        eq(weightRecords.farmId, farmId)
      ));
    return !!result;
  }
  
  // Registros de salud
  async getHealthRecords(farmId: number): Promise<HealthRecord[]> {
    return db
      .select()
      .from(healthRecords)
      .where(eq(healthRecords.farmId, farmId))
      .orderBy(desc(healthRecords.recordDate));
  }
  
  async getHealthRecordById(id: number, farmId: number): Promise<HealthRecord | undefined> {
    const [record] = await db
      .select()
      .from(healthRecords)
      .where(and(
        eq(healthRecords.id, id),
        eq(healthRecords.farmId, farmId)
      ));
    return record;
  }
  
  async createHealthRecord(record: InsertHealthRecord): Promise<HealthRecord> {
    const [newRecord] = await db
      .insert(healthRecords)
      .values(record)
      .returning();
    return newRecord;
  }
  
  async updateHealthRecord(id: number, record: Partial<InsertHealthRecord>): Promise<HealthRecord | undefined> {
    const [updated] = await db
      .update(healthRecords)
      .set({
        ...record,
        updatedAt: new Date()
      })
      .where(eq(healthRecords.id, id))
      .returning();
    return updated;
  }
  
  async deleteHealthRecord(id: number, farmId: number): Promise<boolean> {
    const result = await db
      .delete(healthRecords)
      .where(and(
        eq(healthRecords.id, id),
        eq(healthRecords.farmId, farmId)
      ));
    return !!result;
  }
  
  // Producción de huevos
  async getEggProduction(farmId: number): Promise<EggProduction[]> {
    return db
      .select()
      .from(eggProduction)
      .where(eq(eggProduction.farmId, farmId))
      .orderBy(desc(eggProduction.recordDate));
  }
  
  async getEggProductionById(id: number, farmId: number): Promise<EggProduction | undefined> {
    const [record] = await db
      .select()
      .from(eggProduction)
      .where(and(
        eq(eggProduction.id, id),
        eq(eggProduction.farmId, farmId)
      ));
    return record;
  }
  
  async createEggProduction(record: InsertEggProduction): Promise<EggProduction> {
    const [newRecord] = await db
      .insert(eggProduction)
      .values(record)
      .returning();
    return newRecord;
  }
  
  async updateEggProduction(id: number, record: Partial<InsertEggProduction>): Promise<EggProduction | undefined> {
    const [updated] = await db
      .update(eggProduction)
      .set({
        ...record,
        updatedAt: new Date()
      })
      .where(eq(eggProduction.id, id))
      .returning();
    return updated;
  }
  
  async deleteEggProduction(id: number, farmId: number): Promise<boolean> {
    const result = await db
      .delete(eggProduction)
      .where(and(
        eq(eggProduction.id, id),
        eq(eggProduction.farmId, farmId)
      ));
    return !!result;
  }
}

export const storage = new DatabaseStorage();

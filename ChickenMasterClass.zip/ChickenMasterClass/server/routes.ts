import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import fs from "fs";
import path from "path";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { z } from "zod";
import { insertFarmSchema, insertFinancialProjectionSchema, insertWeightRecordSchema, insertHealthRecordSchema, insertEggProductionSchema } from "@shared/schema";

// Middleware para comprobar autenticación
function isAuthenticated(req: Request, res: Response, next: NextFunction) {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: "No autenticado" });
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Configurar autenticación
  setupAuth(app);
  
  // Serve PDF files
  app.get("/api/pdf/:moduleId", (req, res) => {
    const moduleId = parseInt(req.params.moduleId);
    if (isNaN(moduleId) || moduleId < 1 || moduleId > 9) {
      return res.status(400).send("Invalid module ID");
    }

    const pdfPath = path.resolve(
      import.meta.dirname,
      "..",
      `attached_assets/MODULO_${moduleId}.pdf`
    );

    // Check if file exists
    if (!fs.existsSync(pdfPath)) {
      return res.status(404).send("PDF not found");
    }

    // Set Content-Type and serve the file
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", `inline; filename="MODULO_${moduleId}.pdf"`);
    
    const fileStream = fs.createReadStream(pdfPath);
    fileStream.pipe(res);
  });

  // Download PDF files
  app.get("/api/download/:moduleId", (req, res) => {
    const moduleId = parseInt(req.params.moduleId);
    if (isNaN(moduleId) || moduleId < 1 || moduleId > 9) {
      return res.status(400).send("Invalid module ID");
    }

    const pdfPath = path.resolve(
      import.meta.dirname,
      "..",
      `attached_assets/MODULO_${moduleId}.pdf`
    );

    // Check if file exists
    if (!fs.existsSync(pdfPath)) {
      return res.status(404).send("PDF not found");
    }

    // Set Content-Type and serve the file for download
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", `attachment; filename="MODULO_${moduleId}.pdf"`);
    
    const fileStream = fs.createReadStream(pdfPath);
    fileStream.pipe(res);
  });
  
  // Obtener módulos (videos y cursos)
  app.get("/api/modules", async (req, res) => {
    try {
      const modules = await storage.getModules();
      res.json(modules);
    } catch (err) {
      res.status(500).json({ message: "Error al obtener los módulos" });
    }
  });
  
  app.get("/api/modules/videos", async (req, res) => {
    try {
      const videos = await storage.getVideoModules();
      res.json(videos);
    } catch (err) {
      res.status(500).json({ message: "Error al obtener los videos" });
    }
  });
  
  app.get("/api/modules/:id", async (req, res) => {
    try {
      const moduleId = parseInt(req.params.id);
      const module = await storage.getModuleById(moduleId);
      
      if (!module) {
        return res.status(404).json({ message: "Módulo no encontrado" });
      }
      
      res.json(module);
    } catch (err) {
      res.status(500).json({ message: "Error al obtener el módulo" });
    }
  });
  
  // Rutas protegidas (requieren autenticación)
  
  // Progreso del usuario
  app.get("/api/progress", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user!.id;
      const progress = await storage.getUserProgress(userId);
      res.json(progress);
    } catch (err) {
      res.status(500).json({ message: "Error al obtener el progreso" });
    }
  });
  
  app.post("/api/progress/:moduleId", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user!.id;
      const moduleId = parseInt(req.params.moduleId);
      const progress = await storage.markModuleAsCompleted(userId, moduleId);
      res.json(progress);
    } catch (err) {
      res.status(500).json({ message: "Error al actualizar el progreso" });
    }
  });
  
  // Granjas
  app.get("/api/farms", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user!.id;
      const farms = await storage.getUserFarms(userId);
      res.json(farms);
    } catch (err) {
      res.status(500).json({ message: "Error al obtener las granjas" });
    }
  });
  
  app.get("/api/farms/:id", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user!.id;
      const farmId = parseInt(req.params.id);
      const farm = await storage.getFarmById(farmId, userId);
      
      if (!farm) {
        return res.status(404).json({ message: "Granja no encontrada" });
      }
      
      res.json(farm);
    } catch (err) {
      res.status(500).json({ message: "Error al obtener la granja" });
    }
  });
  
  app.post("/api/farms", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user!.id;
      const validationResult = insertFarmSchema.safeParse({ ...req.body, userId });
      
      if (!validationResult.success) {
        return res.status(400).json({ 
          message: "Datos de granja inválidos", 
          errors: validationResult.error.errors 
        });
      }
      
      const farm = await storage.createFarm(validationResult.data);
      res.status(201).json(farm);
    } catch (err) {
      res.status(500).json({ message: "Error al crear la granja" });
    }
  });
  
  app.patch("/api/farms/:id", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user!.id;
      const farmId = parseInt(req.params.id);
      
      // Verificar que la granja existe y pertenece al usuario
      const farm = await storage.getFarmById(farmId, userId);
      if (!farm) {
        return res.status(404).json({ message: "Granja no encontrada" });
      }
      
      const updated = await storage.updateFarm(farmId, req.body);
      res.json(updated);
    } catch (err) {
      res.status(500).json({ message: "Error al actualizar la granja" });
    }
  });
  
  app.delete("/api/farms/:id", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user!.id;
      const farmId = parseInt(req.params.id);
      
      const result = await storage.deleteFarm(farmId, userId);
      if (!result) {
        return res.status(404).json({ message: "Granja no encontrada" });
      }
      
      res.status(204).end();
    } catch (err) {
      res.status(500).json({ message: "Error al eliminar la granja" });
    }
  });
  
  // Proyecciones financieras
  app.get("/api/farms/:farmId/financials", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user!.id;
      const farmId = parseInt(req.params.farmId);
      
      // Verificar que la granja existe y pertenece al usuario
      const farm = await storage.getFarmById(farmId, userId);
      if (!farm) {
        return res.status(404).json({ message: "Granja no encontrada" });
      }
      
      const projections = await storage.getFinancialProjections(farmId);
      res.json(projections);
    } catch (err) {
      res.status(500).json({ message: "Error al obtener las proyecciones financieras" });
    }
  });
  
  app.post("/api/farms/:farmId/financials", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user!.id;
      const farmId = parseInt(req.params.farmId);
      
      // Verificar que la granja existe y pertenece al usuario
      const farm = await storage.getFarmById(farmId, userId);
      if (!farm) {
        return res.status(404).json({ message: "Granja no encontrada" });
      }
      
      const validationResult = insertFinancialProjectionSchema.safeParse({ 
        ...req.body, 
        farmId 
      });
      
      if (!validationResult.success) {
        return res.status(400).json({ 
          message: "Datos de proyección inválidos", 
          errors: validationResult.error.errors 
        });
      }
      
      const projection = await storage.createFinancialProjection(validationResult.data);
      res.status(201).json(projection);
    } catch (err) {
      res.status(500).json({ message: "Error al crear la proyección financiera" });
    }
  });
  
  app.patch("/api/farms/:farmId/financials/:id", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user!.id;
      const farmId = parseInt(req.params.farmId);
      const projectionId = parseInt(req.params.id);
      
      // Verificar que la granja existe y pertenece al usuario
      const farm = await storage.getFarmById(farmId, userId);
      if (!farm) {
        return res.status(404).json({ message: "Granja no encontrada" });
      }
      
      const updated = await storage.updateFinancialProjection(projectionId, req.body);
      if (!updated) {
        return res.status(404).json({ message: "Proyección no encontrada" });
      }
      
      res.json(updated);
    } catch (err) {
      res.status(500).json({ message: "Error al actualizar la proyección financiera" });
    }
  });
  
  app.delete("/api/farms/:farmId/financials/:id", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user!.id;
      const farmId = parseInt(req.params.farmId);
      const projectionId = parseInt(req.params.id);
      
      // Verificar que la granja existe y pertenece al usuario
      const farm = await storage.getFarmById(farmId, userId);
      if (!farm) {
        return res.status(404).json({ message: "Granja no encontrada" });
      }
      
      const result = await storage.deleteFinancialProjection(projectionId, farmId);
      if (!result) {
        return res.status(404).json({ message: "Proyección no encontrada" });
      }
      
      res.status(204).end();
    } catch (err) {
      res.status(500).json({ message: "Error al eliminar la proyección financiera" });
    }
  });
  
  // Registros de peso
  app.get("/api/farms/:farmId/weights", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user!.id;
      const farmId = parseInt(req.params.farmId);
      
      // Verificar que la granja existe y pertenece al usuario
      const farm = await storage.getFarmById(farmId, userId);
      if (!farm) {
        return res.status(404).json({ message: "Granja no encontrada" });
      }
      
      const records = await storage.getWeightRecords(farmId);
      res.json(records);
    } catch (err) {
      res.status(500).json({ message: "Error al obtener los registros de peso" });
    }
  });
  
  app.post("/api/farms/:farmId/weights", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user!.id;
      const farmId = parseInt(req.params.farmId);
      
      // Verificar que la granja existe y pertenece al usuario
      const farm = await storage.getFarmById(farmId, userId);
      if (!farm) {
        return res.status(404).json({ message: "Granja no encontrada" });
      }
      
      const validationResult = insertWeightRecordSchema.safeParse({ 
        ...req.body, 
        farmId 
      });
      
      if (!validationResult.success) {
        return res.status(400).json({ 
          message: "Datos de registro de peso inválidos", 
          errors: validationResult.error.errors 
        });
      }
      
      const record = await storage.createWeightRecord(validationResult.data);
      res.status(201).json(record);
    } catch (err) {
      res.status(500).json({ message: "Error al crear el registro de peso" });
    }
  });
  
  app.patch("/api/farms/:farmId/weights/:id", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user!.id;
      const farmId = parseInt(req.params.farmId);
      const recordId = parseInt(req.params.id);
      
      // Verificar que la granja existe y pertenece al usuario
      const farm = await storage.getFarmById(farmId, userId);
      if (!farm) {
        return res.status(404).json({ message: "Granja no encontrada" });
      }
      
      const updated = await storage.updateWeightRecord(recordId, req.body);
      if (!updated) {
        return res.status(404).json({ message: "Registro no encontrado" });
      }
      
      res.json(updated);
    } catch (err) {
      res.status(500).json({ message: "Error al actualizar el registro de peso" });
    }
  });
  
  app.delete("/api/farms/:farmId/weights/:id", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user!.id;
      const farmId = parseInt(req.params.farmId);
      const recordId = parseInt(req.params.id);
      
      // Verificar que la granja existe y pertenece al usuario
      const farm = await storage.getFarmById(farmId, userId);
      if (!farm) {
        return res.status(404).json({ message: "Granja no encontrada" });
      }
      
      const result = await storage.deleteWeightRecord(recordId, farmId);
      if (!result) {
        return res.status(404).json({ message: "Registro no encontrado" });
      }
      
      res.status(204).end();
    } catch (err) {
      res.status(500).json({ message: "Error al eliminar el registro de peso" });
    }
  });
  
  // Perfil de usuario
  app.get("/api/user/profile", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user!.id;
      
      // Obtener perfil desde base de datos (podría extenderse para guardar más información)
      const userProfile = {
        userId: userId,
        username: req.user!.username,
        email: req.user!.email,
        farmName: "",
        farmLocation: "",
        farmSize: "",
        henCount: "",
        // Otros datos del perfil
      };
      
      res.json(userProfile);
    } catch (err) {
      res.status(500).json({ message: "Error al obtener el perfil de usuario" });
    }
  });
  
  app.post("/api/user/profile", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user!.id;
      
      // Por ahora, simplemente devolvemos los datos enviados (esto se ampliaría para guardar en BD)
      const profileSchema = z.object({
        farmName: z.string().min(1),
        farmLocation: z.string().min(1),
        farmSize: z.string().optional(),
        henCount: z.string().optional(),
      });
      
      const validationResult = profileSchema.safeParse(req.body);
      
      if (!validationResult.success) {
        return res.status(400).json({ 
          message: "Datos de perfil inválidos", 
          errors: validationResult.error.errors 
        });
      }
      
      // En este punto, guardaríamos en la base de datos
      // Por ahora solo devolvemos los datos validados
      const updatedProfile = {
        userId,
        ...validationResult.data,
      };
      
      res.json(updatedProfile);
    } catch (err) {
      res.status(500).json({ message: "Error al actualizar el perfil de usuario" });
    }
  });
  
  // Registros de salud
  app.get("/api/farms/:farmId/health", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user!.id;
      const farmId = parseInt(req.params.farmId);
      
      // Verificar que la granja existe y pertenece al usuario
      const farm = await storage.getFarmById(farmId, userId);
      if (!farm) {
        return res.status(404).json({ message: "Granja no encontrada" });
      }
      
      const records = await storage.getHealthRecords(farmId);
      res.json(records);
    } catch (err) {
      res.status(500).json({ message: "Error al obtener los registros de sanidad" });
    }
  });
  
  app.post("/api/farms/:farmId/health", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user!.id;
      const farmId = parseInt(req.params.farmId);
      
      // Verificar que la granja existe y pertenece al usuario
      const farm = await storage.getFarmById(farmId, userId);
      if (!farm) {
        return res.status(404).json({ message: "Granja no encontrada" });
      }
      
      const validationResult = insertHealthRecordSchema.safeParse({ 
        ...req.body, 
        farmId 
      });
      
      if (!validationResult.success) {
        return res.status(400).json({ 
          message: "Datos de registro de sanidad inválidos", 
          errors: validationResult.error.errors 
        });
      }
      
      const record = await storage.createHealthRecord(validationResult.data);
      res.status(201).json(record);
    } catch (err) {
      res.status(500).json({ message: "Error al crear el registro de sanidad" });
    }
  });
  
  app.patch("/api/farms/:farmId/health/:id", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user!.id;
      const farmId = parseInt(req.params.farmId);
      const recordId = parseInt(req.params.id);
      
      // Verificar que la granja existe y pertenece al usuario
      const farm = await storage.getFarmById(farmId, userId);
      if (!farm) {
        return res.status(404).json({ message: "Granja no encontrada" });
      }
      
      const updated = await storage.updateHealthRecord(recordId, req.body);
      if (!updated) {
        return res.status(404).json({ message: "Registro no encontrado" });
      }
      
      res.json(updated);
    } catch (err) {
      res.status(500).json({ message: "Error al actualizar el registro de sanidad" });
    }
  });
  
  app.delete("/api/farms/:farmId/health/:id", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user!.id;
      const farmId = parseInt(req.params.farmId);
      const recordId = parseInt(req.params.id);
      
      // Verificar que la granja existe y pertenece al usuario
      const farm = await storage.getFarmById(farmId, userId);
      if (!farm) {
        return res.status(404).json({ message: "Granja no encontrada" });
      }
      
      const result = await storage.deleteHealthRecord(recordId, farmId);
      if (!result) {
        return res.status(404).json({ message: "Registro no encontrado" });
      }
      
      res.status(204).end();
    } catch (err) {
      res.status(500).json({ message: "Error al eliminar el registro de sanidad" });
    }
  });
  
  // Producción de huevos
  app.get("/api/farms/:farmId/eggs", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user!.id;
      const farmId = parseInt(req.params.farmId);
      
      // Verificar que la granja existe y pertenece al usuario
      const farm = await storage.getFarmById(farmId, userId);
      if (!farm) {
        return res.status(404).json({ message: "Granja no encontrada" });
      }
      
      const records = await storage.getEggProduction(farmId);
      res.json(records);
    } catch (err) {
      res.status(500).json({ message: "Error al obtener los registros de producción de huevos" });
    }
  });
  
  app.post("/api/farms/:farmId/eggs", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user!.id;
      const farmId = parseInt(req.params.farmId);
      
      // Verificar que la granja existe y pertenece al usuario
      const farm = await storage.getFarmById(farmId, userId);
      if (!farm) {
        return res.status(404).json({ message: "Granja no encontrada" });
      }
      
      const validationResult = insertEggProductionSchema.safeParse({ 
        ...req.body, 
        farmId 
      });
      
      if (!validationResult.success) {
        return res.status(400).json({ 
          message: "Datos de registro de producción de huevos inválidos", 
          errors: validationResult.error.errors 
        });
      }
      
      const record = await storage.createEggProduction(validationResult.data);
      res.status(201).json(record);
    } catch (err) {
      res.status(500).json({ message: "Error al crear el registro de producción de huevos" });
    }
  });
  
  app.patch("/api/farms/:farmId/eggs/:id", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user!.id;
      const farmId = parseInt(req.params.farmId);
      const recordId = parseInt(req.params.id);
      
      // Verificar que la granja existe y pertenece al usuario
      const farm = await storage.getFarmById(farmId, userId);
      if (!farm) {
        return res.status(404).json({ message: "Granja no encontrada" });
      }
      
      const updated = await storage.updateEggProduction(recordId, req.body);
      if (!updated) {
        return res.status(404).json({ message: "Registro no encontrado" });
      }
      
      res.json(updated);
    } catch (err) {
      res.status(500).json({ message: "Error al actualizar el registro de producción de huevos" });
    }
  });
  
  app.delete("/api/farms/:farmId/eggs/:id", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user!.id;
      const farmId = parseInt(req.params.farmId);
      const recordId = parseInt(req.params.id);
      
      // Verificar que la granja existe y pertenece al usuario
      const farm = await storage.getFarmById(farmId, userId);
      if (!farm) {
        return res.status(404).json({ message: "Granja no encontrada" });
      }
      
      const result = await storage.deleteEggProduction(recordId, farmId);
      if (!result) {
        return res.status(404).json({ message: "Registro no encontrado" });
      }
      
      res.status(204).end();
    } catch (err) {
      res.status(500).json({ message: "Error al eliminar el registro de producción de huevos" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

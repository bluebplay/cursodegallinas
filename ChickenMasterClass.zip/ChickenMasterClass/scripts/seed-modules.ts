import { db } from "../server/db";
import { modules } from "../shared/schema";
import { modules as moduleData } from "../client/src/lib/courseData";

async function seedModules() {
  console.log("Iniciando la carga de módulos en la base de datos...");
  
  try {
    // Verificar si ya hay módulos en la base de datos
    const existingModules = await db.select().from(modules);
    
    if (existingModules.length > 0) {
      console.log(`Ya existen ${existingModules.length} módulos en la base de datos. Omitiendo la carga.`);
      return;
    }
    
    // Preparar los datos de los módulos para inserción
    const modulesForInsert = moduleData.map((module, index) => ({
      id: module.id,
      title: module.title,
      description: module.description,
      content: module.content,
      pdfPath: module.pdfPath,
      videoUrl: module.videoUrl || null,
      videoTitle: module.videoTitle || null,
      orderIndex: index + 1,
      isVideoComplement: !!module.videoUrl, // Si tiene URL de video, es un complemento
      createdAt: new Date(),
      updatedAt: new Date(),
    }));
    
    // Insertar los módulos en la base de datos
    const result = await db.insert(modules).values(modulesForInsert);
    
    console.log(`Se cargaron ${modulesForInsert.length} módulos exitosamente.`);
  } catch (error) {
    console.error("Error al cargar los módulos:", error);
  } finally {
    process.exit(0);
  }
}

seedModules();
import { pgTable, text, serial, integer, boolean, timestamp, real, date } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  firstName: text("first_name"),
  lastName: text("last_name"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const modules = pgTable("modules", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  content: text("content").notNull(),
  pdfPath: text("pdfPath").notNull(),
  videoUrl: text("videoUrl"),
  videoTitle: text("videoTitle"),
  orderIndex: integer("order_index").notNull(),
  isVideoComplement: boolean("is_video_complement").default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const userProgress = pgTable("user_progress", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id, { onDelete: "cascade" }).notNull(),
  moduleId: integer("module_id").references(() => modules.id, { onDelete: "cascade" }).notNull(),
  completed: boolean("completed").default(false).notNull(),
  lastAccessedAt: timestamp("last_accessed_at").defaultNow().notNull(),
});

// Plantillas para gestión de granjas
export const farms = pgTable("farms", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id, { onDelete: "cascade" }).notNull(),
  name: text("name").notNull(),
  location: text("location"),
  size: text("size"),
  henCapacity: integer("hen_capacity"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Proyección de consumo e inversión
export const financialProjections = pgTable("financial_projections", {
  id: serial("id").primaryKey(),
  farmId: integer("farm_id").references(() => farms.id, { onDelete: "cascade" }).notNull(),
  month: date("month").notNull(),
  category: text("category").notNull(), // FEED, MEDICINE, LABOR, EQUIPMENT, UTILITIES, OTHER
  projectedAmount: real("projected_amount").notNull(),
  actualAmount: real("actual_amount"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Registro de peso
export const weightRecords = pgTable("weight_records", {
  id: serial("id").primaryKey(),
  farmId: integer("farm_id").references(() => farms.id, { onDelete: "cascade" }).notNull(),
  recordDate: date("record_date").notNull(),
  batchId: text("batch_id"), // Identificador del lote
  henCount: integer("hen_count").notNull(),
  averageWeight: real("average_weight").notNull(), // En gramos
  minimumWeight: real("minimum_weight"),
  maximumWeight: real("maximum_weight"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Registro de sanidad
export const healthRecords = pgTable("health_records", {
  id: serial("id").primaryKey(),
  farmId: integer("farm_id").references(() => farms.id, { onDelete: "cascade" }).notNull(),
  recordDate: date("record_date").notNull(),
  batchId: text("batch_id"),
  recordType: text("record_type").notNull(), // VACCINATION, TREATMENT, INSPECTION, MORTALITY
  description: text("description").notNull(),
  productUsed: text("product_used"),
  dosage: text("dosage"),
  affectedCount: integer("affected_count"),
  mortality: integer("mortality"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Registro de producción de huevos
export const eggProduction = pgTable("egg_production", {
  id: serial("id").primaryKey(),
  farmId: integer("farm_id").references(() => farms.id, { onDelete: "cascade" }).notNull(),
  recordDate: date("record_date").notNull(),
  batchId: text("batch_id"),
  henCount: integer("hen_count").notNull(),
  eggsCollected: integer("eggs_collected").notNull(),
  brokenEggs: integer("broken_eggs").default(0),
  smallEggs: integer("small_eggs").default(0),
  mediumEggs: integer("medium_eggs").default(0),
  largeEggs: integer("large_eggs").default(0),
  extraLargeEggs: integer("extra_large_eggs").default(0),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Relation definitions
export const modulesRelations = relations(modules, ({ many }) => ({
  userProgresses: many(userProgress),
}));

export const usersRelations = relations(users, ({ many }) => ({
  progresses: many(userProgress),
  farms: many(farms),
}));

export const userProgressRelations = relations(userProgress, ({ one }) => ({
  user: one(users, {
    fields: [userProgress.userId],
    references: [users.id],
  }),
  module: one(modules, {
    fields: [userProgress.moduleId],
    references: [modules.id],
  }),
}));

export const farmsRelations = relations(farms, ({ one, many }) => ({
  user: one(users, {
    fields: [farms.userId],
    references: [users.id],
  }),
  financialProjections: many(financialProjections),
  weightRecords: many(weightRecords),
  healthRecords: many(healthRecords),
  eggProduction: many(eggProduction),
}));

export const financialProjectionsRelations = relations(financialProjections, ({ one }) => ({
  farm: one(farms, {
    fields: [financialProjections.farmId],
    references: [farms.id],
  }),
}));

export const weightRecordsRelations = relations(weightRecords, ({ one }) => ({
  farm: one(farms, {
    fields: [weightRecords.farmId],
    references: [farms.id],
  }),
}));

export const healthRecordsRelations = relations(healthRecords, ({ one }) => ({
  farm: one(farms, {
    fields: [healthRecords.farmId],
    references: [farms.id],
  }),
}));

export const eggProductionRelations = relations(eggProduction, ({ one }) => ({
  farm: one(farms, {
    fields: [eggProduction.farmId],
    references: [farms.id],
  }),
}));

// Schemas for validation and insertion
export const insertUserSchema = createInsertSchema(users).pick({
  email: true,
  username: true,
  password: true,
  firstName: true,
  lastName: true,
});

export const insertModuleSchema = createInsertSchema(modules);
export const insertUserProgressSchema = createInsertSchema(userProgress);
export const insertFarmSchema = createInsertSchema(farms);
export const insertFinancialProjectionSchema = createInsertSchema(financialProjections);
export const insertWeightRecordSchema = createInsertSchema(weightRecords);
export const insertHealthRecordSchema = createInsertSchema(healthRecords);
export const insertEggProductionSchema = createInsertSchema(eggProduction);

// Types for TypeScript
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Module = typeof modules.$inferSelect;
export type InsertModule = typeof modules.$inferInsert;
export type UserProgress = typeof userProgress.$inferSelect;
export type InsertUserProgress = typeof userProgress.$inferInsert;
export type Farm = typeof farms.$inferSelect;
export type InsertFarm = typeof farms.$inferInsert;
export type FinancialProjection = typeof financialProjections.$inferSelect;
export type InsertFinancialProjection = typeof financialProjections.$inferInsert;
export type WeightRecord = typeof weightRecords.$inferSelect;
export type InsertWeightRecord = typeof weightRecords.$inferInsert;
export type HealthRecord = typeof healthRecords.$inferSelect;
export type InsertHealthRecord = typeof healthRecords.$inferInsert;
export type EggProduction = typeof eggProduction.$inferSelect;
export type InsertEggProduction = typeof eggProduction.$inferInsert;

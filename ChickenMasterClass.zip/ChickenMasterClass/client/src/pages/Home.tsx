import { useState, useEffect } from "react";
import { Menu, Egg, BookOpenCheck, LogOut, Video, Database, User } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { getQueryFn } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import ModuleList from "@/components/ModuleList";
import ModuleCard from "@/components/ModuleCard";
import ModuleDetail from "@/components/ModuleDetail";
import PdfViewer from "@/components/PdfViewer";
import VideoPlayer from "@/components/VideoPlayer";
import MobileMenu from "@/components/MobileMenu";
import { modules as localModules } from "@/lib/courseData";
import { CommonModule } from "@/hooks/use-common-types";
import { Module as DbModule } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function Home() {
  const [selectedModule, setSelectedModule] = useState<CommonModule | null>(null);
  const [viewMode, setViewMode] = useState<"grid" | "detail" | "pdf" | "video">("grid");
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [location, navigate] = useLocation();
  const { user, logoutMutation } = useAuth();

  // Obtener módulos desde la base de datos (excluyendo videos complementarios)
  const { data: dbModules, isLoading: modulesLoading } = useQuery<DbModule[]>({
    queryKey: ["/api/modules"],
    queryFn: getQueryFn({ on401: "returnNull" }),
  });

  // Fallback a los módulos locales si no hay datos de la API
  const modules = dbModules || localModules;

  const handleModuleSelect = (module: CommonModule) => {
    setSelectedModule(module);
    setViewMode("detail");
    window.scrollTo(0, 0);
  };

  const handleBackToModules = () => {
    setViewMode("grid");
  };

  const handleViewPdf = () => {
    setViewMode("pdf");
  };

  const handleViewVideo = () => {
    if (selectedModule && selectedModule.videoUrl) {
      setViewMode("video");
    }
  };

  const handleClosePdf = () => {
    setViewMode("detail");
  };

  const handleCloseVideo = () => {
    setViewMode("detail");
  };

  const handleLogout = () => {
    localStorage.removeItem("curso-authenticated");
    window.location.reload();
  };

  const navigateToDashboard = () => {
    navigate("/dashboard");
  };

  const navigateToAuth = () => {
    navigate("/auth");
  };

  return (
    <div className="flex flex-col min-h-screen">
      {/* Header principal - Desktop */}
      <header className="hidden md:block bg-gradient-to-r from-primary to-secondary text-white shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center">
              <Egg className="h-7 w-7 mr-3" />
              <h1 className="text-xl font-heading font-semibold">Curso de Gallinas Ponedoras</h1>
            </div>
            
            <nav className="flex items-center space-x-8">
              <button
                onClick={() => {
                  setViewMode("grid");
                  setSelectedModule(null);
                }}
                className={`text-white hover:text-accent transition flex items-center py-2 border-b-2 ${
                  viewMode === "grid" ? "border-accent" : "border-transparent"
                }`}
              >
                <BookOpenCheck className="h-4 w-4 mr-2" />
                <span>Módulos</span>
              </button>
              
              <button
                onClick={() => navigate("/videos")}
                className="text-white hover:text-accent transition flex items-center py-2 border-b-2 border-transparent"
              >
                <Video className="h-4 w-4 mr-2" />
                <span>Videos</span>
              </button>
              
              {user ? (
                <>
                  <button
                    onClick={navigateToDashboard}
                    className="text-white hover:text-accent transition flex items-center py-2 border-b-2 border-transparent"
                  >
                    <Database className="h-4 w-4 mr-2" />
                    <span>Registros</span>
                  </button>
                  
                  <button
                    onClick={() => navigate("/profile")}
                    className="text-white hover:text-accent transition flex items-center py-2 border-b-2 border-transparent"
                  >
                    <User className="h-4 w-4 mr-2" />
                    <span>Mi Perfil</span>
                  </button>
                </>
              ) : (
                <button
                  onClick={navigateToAuth}
                  className="text-white hover:text-accent transition flex items-center py-2 border-b-2 border-transparent"
                >
                  <User className="h-4 w-4 mr-2" />
                  <span>Iniciar Sesión</span>
                </button>
              )}
              
              <button
                onClick={handleLogout}
                className="text-white hover:text-accent transition flex items-center py-2 border-b-2 border-transparent"
              >
                <LogOut className="h-4 w-4 mr-2" />
                <span>Salir</span>
              </button>
            </nav>
          </div>
        </div>
      </header>
      
      {/* Header para móvil */}
      <div className="md:hidden bg-gradient-to-r from-primary to-secondary text-white p-4 sticky top-0 z-40 shadow-md">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <Egg className="h-6 w-6 mr-2" />
            <h1 className="text-lg font-heading font-medium">Curso de Gallinas Ponedoras</h1>
          </div>
          <button 
            onClick={() => setIsMobileMenuOpen(true)}
            className="focus:outline-none hover:text-accent transition-colors"
          >
            <Menu className="h-6 w-6" />
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <MobileMenu 
        isOpen={isMobileMenuOpen} 
        onClose={() => setIsMobileMenuOpen(false)} 
        onModuleSelect={(module) => {
          handleModuleSelect(module);
          setIsMobileMenuOpen(false);
        }}
        onLogout={handleLogout}
      />

      <div className="flex flex-col flex-1">
        {/* Main content area */}
        <div className="flex-1 p-4 md:p-8">
          <div className="max-w-6xl mx-auto">
            {/* Header */}
            {viewMode === "grid" && (
              <header className="mb-12 text-center">
                <div className="inline-block p-3 rounded-full bg-accent/10 text-accent mb-4">
                  <BookOpenCheck className="h-8 w-8" />
                </div>
                <h1 className="text-3xl md:text-5xl font-heading font-bold gradient-heading mb-4">
                  Bienvenido al Curso de Gallinas Ponedoras
                </h1>
                <p className="text-gray-600 text-lg max-w-2xl mx-auto">
                  Aprende todo lo necesario para gestionar un negocio de gallinas ponedoras exitoso a través de nuestros módulos especializados
                </p>
                
                {/* Decorative element */}
                <div className="flex justify-center mt-8 mb-12">
                  <div className="w-24 h-1 bg-gradient-to-r from-primary to-secondary rounded-full"></div>
                </div>
                
                {/* CTAs */}
                <div className="mt-4 mb-8 flex flex-col md:flex-row justify-center gap-4">
                  <Button 
                    size="lg" 
                    className="bg-gradient-to-r from-primary to-secondary hover:from-primary/90 hover:to-secondary/90"
                    onClick={user ? navigateToDashboard : navigateToAuth}
                  >
                    <Database className="h-5 w-5 mr-2" />
                    {user 
                      ? "Ir a mis registros" 
                      : "Registrarme para llevar control de mi granja"}
                  </Button>
                  
                  <Button 
                    size="lg" 
                    variant="outline"
                    className="border-primary text-primary hover:bg-primary hover:text-white"
                    onClick={() => navigate("/videos")}
                  >
                    <Video className="h-5 w-5 mr-2" />
                    Ver videos complementarios
                  </Button>
                </div>
              </header>
            )}

            {/* Module grid view */}
            {viewMode === "grid" && (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
                {modules.map((module) => (
                  <ModuleCard 
                    key={module.id} 
                    module={module} 
                    onClick={() => handleModuleSelect(module)} 
                  />
                ))}
              </div>
            )}

            {/* Module detail view */}
            {viewMode === "detail" && selectedModule && (
              <ModuleDetail 
                module={selectedModule} 
                onBack={handleBackToModules} 
                onView={handleViewPdf} 
                onViewVideo={selectedModule.videoUrl ? handleViewVideo : undefined}
              />
            )}

            {/* PDF viewer */}
            {viewMode === "pdf" && selectedModule && (
              <PdfViewer 
                module={selectedModule} 
                onClose={handleClosePdf} 
              />
            )}
            
            {/* Video player */}
            {viewMode === "video" && selectedModule && selectedModule.videoUrl && (
              <VideoPlayer
                module={selectedModule}
                onClose={handleCloseVideo}
              />
            )}
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gradient-to-r from-primary to-secondary text-white py-6 text-center shadow-inner">
        <div className="max-w-6xl mx-auto px-4">
          <p className="text-base font-medium uppercase tracking-wider">Curso exclusivo, prohibida su distribución</p>
          <div className="w-16 h-0.5 bg-white/20 mx-auto my-4"></div>
          <p className="text-sm opacity-80">© {new Date().getFullYear()} Curso de Gallinas Ponedoras. Todos los derechos reservados.</p>
        </div>
      </footer>
    </div>
  );
}

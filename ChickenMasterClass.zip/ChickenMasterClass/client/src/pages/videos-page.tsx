import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { getQueryFn } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { Video, ArrowLeft } from "lucide-react";
import VideoCard from "@/components/VideoCard";
import VideoDetail from "@/components/VideoDetail";
import VideoPlayer from "@/components/VideoPlayer";
import { modules as localModules } from "@/lib/courseData";
import { CommonModule } from "@/hooks/use-common-types";
import { Module as DbModule } from "@shared/schema";
import { Button } from "@/components/ui/button";

export default function VideosPage() {
  const [selectedModule, setSelectedModule] = useState<CommonModule | null>(null);
  const [viewMode, setViewMode] = useState<"grid" | "detail" | "video">("grid");
  const [location, navigate] = useLocation();
  const { user } = useAuth();

  // Obtener módulos de video complementarios
  const { data: videoModules, isLoading: videosLoading } = useQuery<DbModule[]>({
    queryKey: ["/api/modules/videos"],
    queryFn: getQueryFn({ on401: "returnNull" }),
  });

  // Fallback a los módulos locales si no hay datos de la API (solo los que tienen videos)
  const videos = videoModules || localModules.filter(m => m.videoUrl);

  // Seleccionar un video para ver detalles
  const handleModuleSelect = (module: CommonModule) => {
    setSelectedModule(module);
    setViewMode("detail");
    window.scrollTo(0, 0);
  };

  // Volver a la cuadrícula de videos
  const handleBackToVideos = () => {
    setViewMode("grid");
  };

  // Ver el video
  const handleViewVideo = () => {
    if (selectedModule && selectedModule.videoUrl) {
      setViewMode("video");
    }
  };

  // Cerrar el video
  const handleCloseVideo = () => {
    setViewMode("detail");
  };

  return (
    <div className="container py-8 max-w-6xl mx-auto">
      <div className="mb-8">
        <Button
          variant="ghost"
          className="flex items-center mb-4"
          onClick={() => navigate("/")}
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Volver al inicio
        </Button>
        
        {viewMode === "grid" && (
          <>
            <div className="text-center mb-12">
              <div className="inline-block p-3 rounded-full bg-accent/10 text-accent mb-4">
                <Video className="h-8 w-8" />
              </div>
              <h1 className="text-3xl md:text-4xl font-heading font-bold gradient-heading mb-4">
                Videos Complementarios
              </h1>
              <p className="text-gray-600 text-lg max-w-2xl mx-auto">
                Material audiovisual complementario para reforzar los conceptos del curso con ejemplos prácticos y explicaciones detalladas
              </p>
              
              {/* Decorative element */}
              <div className="flex justify-center mt-8 mb-4">
                <div className="w-24 h-1 bg-gradient-to-r from-primary to-secondary rounded-full"></div>
              </div>
            </div>
          </>
        )}
        
        {viewMode === "video" && selectedModule && (
          <h1 className="text-2xl md:text-3xl font-heading font-bold">
            Reproduciendo: {selectedModule.title}
          </h1>
        )}
      </div>

      {/* Video grid view */}
      {viewMode === "grid" && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {videos.map((module) => (
            <VideoCard 
              key={module.id} 
              module={module} 
              onClick={() => handleModuleSelect(module)}
            />
          ))}
        </div>
      )}

      {/* Video detail view */}
      {viewMode === "detail" && selectedModule && selectedModule.videoUrl && (
        <VideoDetail 
          module={selectedModule} 
          onBack={handleBackToVideos} 
          onViewVideo={handleViewVideo}
        />
      )}
      
      {/* Video player */}
      {viewMode === "video" && selectedModule && selectedModule.videoUrl && (
        <VideoPlayer
          module={selectedModule}
          onClose={handleCloseVideo}
        />
      )}
    </div>
  );
}
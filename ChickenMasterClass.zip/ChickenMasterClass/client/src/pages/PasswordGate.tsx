import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { FeatherIcon } from "lucide-react";

interface PasswordGateProps {
  onAuthenticate: (status: boolean) => void;
}

export default function PasswordGate({ onAuthenticate }: PasswordGateProps) {
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === "cursodegallinas24") {
      onAuthenticate(true);
    } else {
      setError("Contraseña incorrecta. Por favor intente de nuevo.");
      setPassword("");
    }
  };

  return (
    <div className="fixed inset-0 bg-white z-50 flex items-center justify-center p-4">
      <Card className="bg-white rounded-lg shadow-xl p-6 max-w-md w-full border border-gray-200">
        <CardContent className="pt-6">
          <div className="text-center mb-6">
            <div className="flex justify-center mb-3">
              <FeatherIcon className="text-primary h-12 w-12" />
            </div>
            <h2 className="text-2xl font-heading font-semibold text-accent">
              Curso de Gallinas Ponedoras
            </h2>
            <p className="text-gray-600 mt-2">
              Por favor, ingrese la contraseña para acceder al contenido del curso.
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="password" className="text-sm font-medium text-gray-700 mb-1">
                Contraseña
              </Label>
              <Input
                type="password"
                id="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                required
              />
            </div>

            {error && (
              <div className="text-destructive text-sm font-medium">{error}</div>
            )}

            <Button
              type="submit"
              className="w-full bg-primary hover:bg-accent text-white font-medium py-2 px-4 rounded-md transition duration-300"
            >
              Acceder al Curso
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}

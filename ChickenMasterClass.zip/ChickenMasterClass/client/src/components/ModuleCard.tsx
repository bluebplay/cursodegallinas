import { CommonModule } from "@/hooks/use-common-types";
import { Button } from "@/components/ui/button";
import { BookOpenText, Video, Play } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface ModuleCardProps {
  module: CommonModule;
  onClick: () => void;
  isVideo?: boolean;
}

export default function ModuleCard({ module, onClick, isVideo = false }: ModuleCardProps) {
  return (
    <div className="module-card">
      <div className={`module-card-header ${isVideo ? 'bg-gradient-to-r from-indigo-600 to-violet-600' : ''}`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <div className="bg-white/20 rounded-full w-8 h-8 flex items-center justify-center mr-2">
              <span className="text-white font-bold">{module.id}</span>
            </div>
            <h3 className="font-heading font-semibold">
              {isVideo ? "Video" : "Módulo"} {module.id}
            </h3>
          </div>
          
          {module.videoUrl && !isVideo && (
            <Badge variant="secondary" className="bg-white/20 hover:bg-white/30">
              +Video
            </Badge>
          )}
        </div>
      </div>
      <div className="p-6">
        <h4 className="text-lg font-heading font-medium text-gray-800 mb-2 gradient-heading">
          {module.title}
        </h4>
        <p className="text-gray-600 text-sm mb-4">{module.description}</p>
        
        <Button 
          onClick={onClick}
          className={`w-full flex items-center justify-center ${isVideo ? 'bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-700 hover:to-violet-700' : 'btn-primary'}`}
        >
          {isVideo ? (
            <Play className="h-4 w-4 mr-2" />
          ) : (
            <BookOpenText className="h-4 w-4 mr-2" />
          )}
          Ver {isVideo ? "video" : "detalles"}
        </Button>
      </div>
    </div>
  );
}

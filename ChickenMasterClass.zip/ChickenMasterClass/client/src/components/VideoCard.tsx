import { CommonModule } from "@/hooks/use-common-types";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Video, PlayCircle } from "lucide-react";

interface VideoCardProps {
  module: CommonModule;
  onClick: () => void;
}

export default function VideoCard({ module, onClick }: VideoCardProps) {
  return (
    <Card 
      className="overflow-hidden transition-all duration-300 hover:shadow-lg hover:shadow-primary/10 hover:scale-[1.02] cursor-pointer relative"
      onClick={onClick}
    >
      {/* Indicador de video */}
      <div className="absolute top-3 right-3 bg-primary text-white text-xs px-2 py-1 rounded-full flex items-center shadow-md">
        <Video className="h-3 w-3 mr-1" />
        <span>Video</span>
      </div>
      
      <CardHeader className="pb-2">
        <CardTitle className="line-clamp-2 text-lg h-[3.6rem] flex items-center">
          {module.title}
        </CardTitle>
      </CardHeader>
      
      <CardContent>
        <div className="h-[150px] mb-4 rounded-md bg-gradient-to-br from-accent/10 to-primary/10 flex flex-col items-center justify-center relative">
          <div className="absolute inset-0 flex items-center justify-center">
            <PlayCircle className="h-16 w-16 text-primary/80 group-hover:text-primary transition-colors" />
          </div>
          {module.videoTitle && (
            <div className="absolute bottom-0 left-0 right-0 p-2 bg-black/60 text-white text-xs text-center">
              {module.videoTitle}
            </div>
          )}
        </div>
        
        <CardDescription className="line-clamp-3 h-[4.5rem] text-sm">
          {module.description}
        </CardDescription>
      </CardContent>
      
      <CardFooter>
        <Button 
          className="w-full group hover:bg-primary"
          variant="outline"
          onClick={(e) => {
            e.stopPropagation();
            onClick();
          }}
        >
          <PlayCircle className="h-4 w-4 mr-2 text-primary group-hover:text-white transition-colors" />
          <span className="group-hover:text-white transition-colors">Ver Video</span>
        </Button>
      </CardFooter>
    </Card>
  );
}
import { CommonModule } from "@/hooks/use-common-types";
import { cn } from "@/lib/utils";

interface ModuleListProps {
  modules: CommonModule[];
  onModuleSelect: (module: CommonModule) => void;
  currentModuleId?: number;
}

export default function ModuleList({ modules, onModuleSelect, currentModuleId }: ModuleListProps) {
  return (
    <div className="p-4">
      <ul className="space-y-2">
        {modules.map((module) => (
          <li key={module.id}>
            <a 
              href="#" 
              className={cn(
                "flex items-center py-2 px-3 rounded-md transition duration-200",
                currentModuleId === module.id 
                  ? "bg-primary/10 text-primary" 
                  : "hover:bg-gray-100 text-gray-700 hover:text-primary"
              )}
              onClick={(e) => {
                e.preventDefault();
                onModuleSelect(module);
              }}
            >
              <span className="w-6 h-6 flex items-center justify-center bg-primary text-white rounded-full text-xs mr-2">
                {module.id}
              </span>
              {module.title}
              {module.videoUrl && (
                <span className="ml-2 text-xs font-semibold px-2 py-0.5 rounded-full bg-amber-100 text-amber-700">
                  +Video
                </span>
              )}
            </a>
          </li>
        ))}
      </ul>
    </div>
  );
}

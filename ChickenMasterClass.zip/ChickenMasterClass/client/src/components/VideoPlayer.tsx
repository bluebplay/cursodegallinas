import React from "react";
import { CommonModule } from "@/hooks/use-common-types";
import { Button } from "@/components/ui/button";
import { X, Film } from "lucide-react";

interface VideoPlayerProps {
  module: CommonModule;
  onClose: () => void;
}

export default function VideoPlayer({ module, onClose }: VideoPlayerProps) {
  if (!module.videoUrl) {
    return (
      <div className="flex flex-col items-center justify-center bg-neutral-100 p-10 rounded-lg border border-neutral-200 shadow-md">
        <Film className="w-16 h-16 text-gray-400 mb-4" />
        <h3 className="text-xl font-heading font-semibold text-gray-600">Video no disponible</h3>
        <p className="text-gray-500 mt-2 text-center">Este módulo no tiene video complementario</p>
        <Button 
          variant="outline" 
          onClick={onClose} 
          className="mt-6"
        >
          Volver
        </Button>
      </div>
    );
  }

  // Determinar si este es un módulo de video o un módulo regular con video complementario
  const isVideoModule = module.isVideoComplement === true;

  return (
    <div className="fade-in">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-heading font-bold gradient-heading">
          {module.videoTitle || `Video: ${module.title}`}
        </h2>
        <Button
          variant="ghost"
          onClick={onClose}
          className="flex items-center text-primary hover:text-accent transition duration-300"
        >
          <X className="h-4 w-4 mr-2" /> Cerrar
        </Button>
      </div>
      
      <div className="bg-white rounded-lg shadow-lg overflow-hidden border border-neutral-200">
        <div className="aspect-w-16 aspect-h-9">
          <iframe
            src={module.videoUrl}
            title={module.videoTitle || `Video del módulo ${module.id}`}
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
            className="w-full h-full"
          ></iframe>
        </div>
        
        <div className="p-4 bg-gray-50 border-t">
          <h3 className="font-heading font-medium text-gray-800">
            {isVideoModule ? "Video" : "Módulo"} {module.id}: {module.title}
          </h3>
          <p className="text-gray-600 text-sm mt-1">
            {isVideoModule 
              ? "Video principal del módulo" 
              : "Video complementario para reforzar tu aprendizaje"}
          </p>
        </div>
      </div>
      
      <div className="mt-6 bg-blue-50 p-4 rounded-lg border border-blue-200 text-blue-700">
        <h4 className="font-heading font-medium mb-2 flex items-center">
          <svg className="h-5 w-5 mr-2" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
            <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd"></path>
          </svg>
          Tip: Visualización óptima
        </h4>
        <p className="text-sm">
          Para una mejor experiencia de aprendizaje, te recomendamos ver el video completo y tomar notas de los puntos clave. 
          Puedes alternar entre el video y el material PDF para reforzar los conceptos aprendidos.
        </p>
      </div>
    </div>
  );
}
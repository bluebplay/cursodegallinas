import { CommonModule } from "@/hooks/use-common-types";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, PlayCircle, Video } from "lucide-react";

interface VideoDetailProps {
  module: CommonModule;
  onBack: () => void;
  onViewVideo: () => void;
}

export default function VideoDetail({ module, onBack, onViewVideo }: VideoDetailProps) {
  return (
    <div className="space-y-6">
      <Card className="overflow-hidden shadow-lg border-0 bg-white">
        <CardHeader className="border-b pb-6">
          <Button variant="ghost" onClick={onBack} className="p-0 mb-4 h-auto hover:bg-transparent hover:text-primary">
            <ArrowLeft className="mr-2 h-4 w-4" />
            <span>Volver a videos</span>
          </Button>
          <CardTitle className="text-2xl font-bold">{module.title}</CardTitle>
          <div className="flex items-center mt-2">
            <div className="bg-primary/10 p-1 rounded-full mr-2">
              <Video className="h-4 w-4 text-primary" />
            </div>
            <CardDescription>Video Complementario</CardDescription>
          </div>
        </CardHeader>
        
        <CardContent className="py-6">
          <div className="grid md:grid-cols-3 gap-8">
            <div className="md:col-span-1">
              <div 
                className="aspect-video bg-gradient-to-br from-accent/10 to-primary/10 rounded-lg flex items-center justify-center cursor-pointer relative"
                onClick={onViewVideo}
              >
                <div className="absolute inset-0 flex items-center justify-center transition-transform hover:scale-105">
                  <PlayCircle className="h-24 w-24 text-primary opacity-80 hover:opacity-100 transition-opacity" />
                </div>
                {module.videoTitle && (
                  <div className="absolute bottom-0 left-0 right-0 p-3 bg-black/60 text-white text-sm">
                    {module.videoTitle}
                  </div>
                )}
              </div>
              
              <Button 
                className="w-full mt-4 bg-gradient-to-r from-primary to-secondary hover:from-primary/90 hover:to-secondary/90"
                onClick={onViewVideo}
              >
                <PlayCircle className="mr-2 h-5 w-5" />
                Reproducir Video
              </Button>
            </div>
            
            <div className="md:col-span-2">
              <h3 className="text-lg font-semibold mb-3">Descripción del Video</h3>
              <div className="text-gray-700 space-y-4">
                <p>{module.description}</p>
              </div>
              
              <div className="mt-6 pt-6 border-t">
                <h3 className="text-lg font-semibold mb-2">Información de contenido</h3>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <div className="bg-primary/10 p-1 rounded-full mr-2 mt-0.5">
                      <Video className="h-4 w-4 text-primary" />
                    </div>
                    <span>
                      Este video complementa el contenido teórico del módulo con ejemplos prácticos y visuales.
                    </span>
                  </li>
                  {module.videoTitle && (
                    <li className="flex items-start">
                      <div className="bg-primary/10 p-1 rounded-full mr-2 mt-0.5">
                        <PlayCircle className="h-4 w-4 text-primary" />
                      </div>
                      <span>
                        Título del video: <span className="font-medium">{module.videoTitle}</span>
                      </span>
                    </li>
                  )}
                </ul>
              </div>
            </div>
          </div>
        </CardContent>
        
        <CardFooter className="border-t pt-6 flex justify-end">
          <Button variant="outline" onClick={onBack} className="mr-2">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Volver
          </Button>
          <Button onClick={onViewVideo}>
            <PlayCircle className="mr-2 h-4 w-4" />
            Ver Video
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}